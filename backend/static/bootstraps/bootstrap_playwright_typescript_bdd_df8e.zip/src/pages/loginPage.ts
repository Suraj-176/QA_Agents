import { Page, Locator } from '@playwright/test';
import { Logger } from '../../core/logger/Logger'; // Assuming Logger path
import { Config } from '../../core/config/Config'; // Assuming Config path

/**
 * Represents the Login Page Object Model (POM).
 * Provides methods to interact with the login page elements.
 */
export class LoginPage {
    private readonly page: Page;
    private readonly config: Config;
    private readonly logger: Logger;

    // Locators
    private readonly usernameInput: Locator;
    private readonly passwordInput: Locator;
    private readonly loginButton: Locator;
    private readonly successMessage: Locator;
    private readonly errorMessage: Locator;

    constructor(page: Page, config: Config) {
        this.page = page;
        this.config = config;
        this.logger = new Logger(LoginPage.name); // Initialize logger
        this.usernameInput = page.locator('input[name="username"]');
        this.passwordInput = page.locator('input[name="password"]');
        this.loginButton = page.locator('button[type="submit"]');
        this.successMessage = page.locator('.alert-success');
        this.errorMessage = page.locator('.alert-danger');
    }

    /**
     * Navigates to the login page.
     * @returns {LoginPage} The current LoginPage instance for fluent chaining.
     */
    async navigateToLoginPage(): Promise<LoginPage> {
        this.logger.info(`Navigating to login page: ${this.config.baseUrl}/login`);
        await this.page.goto(`${this.config.baseUrl}/login`);
        return this;
    }

    /**
     * Enters the username into the username input field.
     * @param {string} username - The username to enter.
     * @returns {LoginPage} The current LoginPage instance for fluent chaining.
     */
    async enterUsername(username: string): Promise<LoginPage> {
        this.logger.debug(`Entering username: ${username}`);
        await this.usernameInput.fill(username);
        return this;
    }

    /**
     * Enters the password into the password input field.
     * @param {string} password - The password to enter.
     * @returns {LoginPage} The current LoginPage instance for fluent chaining.
     */
    async enterPassword(password: string): Promise<LoginPage> {
        this.logger.debug(`Entering password: ${password}`);
        await this.passwordInput.fill(password);
        return this;
    }

    /**
     * Clicks the login button.
     * @returns {LoginPage} The current LoginPage instance for fluent chaining.
     */
    async clickLoginButton(): Promise<LoginPage> {
        this.logger.debug('Clicking login button');
        await this.loginButton.click();
        return this;
    }

    /**
     * Performs a full login operation.
     * @param {string} username - The username to use for login.
     * @param {string} password - The password to use for login.
     * @returns {LoginPage} The current LoginPage instance for fluent chaining.
     */
    async login(username: string, password: string): Promise<LoginPage> {
        this.logger.info(`Attempting to login with username: ${username}`);
        await this.enterUsername(username);
        await this.enterPassword(password);
        await this.clickLoginButton();
        return this;
    }

    /**
     * Gets the text content of the success message.
     * @returns {Promise<string | null>} The text content of the success message, or null if not found.
     */
    async getSuccessMessageText(): Promise<string | null> {
        this.logger.debug('Getting success message text');
        await this.successMessage.waitFor({ state: 'visible', timeout: 5000 });
        return await this.successMessage.textContent();
    }

    /**
     * Gets the text content of the error message.
     * @returns {Promise<string | null>} The text content of the error message, or null if not found.
     */
    async getErrorMessageText(): Promise<string | null> {
        this.logger.debug('Getting error message text');
        await this.errorMessage.waitFor({ state: 'visible', timeout: 5000 });
        return await this.errorMessage.textContent();
    }
}