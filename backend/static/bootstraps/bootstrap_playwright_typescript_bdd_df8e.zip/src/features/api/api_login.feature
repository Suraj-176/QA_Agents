Feature: API Login Functionality

  As a developer, I want to be able to log in via API
  So that I can obtain an authentication token for subsequent API calls.

  Scenario: Successful API Login with valid credentials
    Given the API endpoint "/api/login"
    When I send a POST request with username "api_user" and password "api_password"
    Then the API response status should be 200
    And the API response should contain an authentication token