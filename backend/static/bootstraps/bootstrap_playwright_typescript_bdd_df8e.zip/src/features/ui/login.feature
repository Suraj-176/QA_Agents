Feature: UI Login Functionality

  As a user, I want to be able to log in to the application
  So that I can access protected features.

  Scenario: Successful UI Login with valid credentials
    Given I am on the login page
    When I enter "user@example.com" as username
    And I enter "password123" as password
    And I click the "Login" button
    Then I should see a success message "Welcome, user!"