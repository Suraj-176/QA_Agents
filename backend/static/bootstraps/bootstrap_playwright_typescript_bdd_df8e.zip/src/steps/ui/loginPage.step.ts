import { Given, When, Then, World } from '@cucumber/cucumber';
import { expect } from '@playwright/test';
import { LoginPage } from '../../pages/loginPage';
import { LoginValidator } from '../../../helpers/validators/LoginValidator';
import { allure } from 'allure-playwright';
import { Config } from '../../core/config/Config'; // Assuming Config path

// Extend Cucumber World to include Playwright page and Config
interface CustomWorld extends World {
    page: any; // Playwright Page object
    config: Config; // Config object
    loginPage: LoginPage;
    loginValidator: LoginValidator;
}

Given('I am on the login page', async function (this: CustomWorld) {
    await allure.step('Navigate to login page', async () => {
        this.loginPage = new LoginPage(this.page, this.config);
        await this.loginPage.navigateToLoginPage();
        this.loginValidator = new LoginValidator();
    });
});

When('I enter {string} as username', async function (this: CustomWorld, username: string) {
    await allure.step(`Enter username: ${username}`, async () => {
        await this.loginPage.enterUsername(username);
    });
});

When('I enter {string} as password', async function (this: CustomWorld, password: string) {
    await allure.step(`Enter password: ${password}`, async () => {
        await this.loginPage.enterPassword(password);
    });
});

When('I click the {string} button', async function (this: CustomWorld, buttonName: string) {
    await allure.step(`Click button: ${buttonName}`, async () => {
        // Assuming 'Login' is the only button for now, or we can extend LoginPage to handle generic buttons
        if (buttonName === 'Login') {
            await this.loginPage.clickLoginButton();
        } else {
            throw new Error(`Button "${buttonName}" not recognized.`);
        }
    });
});

Then('I should see a success message {string}', async function (this: CustomWorld, expectedMessage: string) {
    await allure.step(`Verify success message: "${expectedMessage}"`, async () => {
        const actualMessage = await this.loginPage.getSuccessMessageText();
        expect(this.loginValidator.isLoginSuccessMessageValid(actualMessage, expectedMessage)).toBe(true);
    });
});

Then('I should see an error message {string}', async function (this: CustomWorld, expectedMessage: string) {
    await allure.step(`Verify error message: "${expectedMessage}"`, async () => {
        const actualMessage = await this.loginPage.getErrorMessageText();
        expect(this.loginValidator.isLoginErrorMessageValid(actualMessage, expectedMessage)).toBe(true);
    });
});