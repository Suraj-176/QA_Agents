import { Given, When, Then, World } from '@cucumber/cucumber';
import { expect, APIRequestContext, APIResponse } from '@playwright/test';
import { LoginValidator } from '../../../helpers/validators/LoginValidator';
import { allure } from 'allure-playwright';
import { Config } from '../../core/config/Config'; // Assuming Config path

// Extend Cucumber World to include Playwright page, Config, and API context
interface CustomWorld extends World {
    page: any; // Playwright Page object (might not be used for API steps, but part of World)
    config: Config; // Config object
    request: APIRequestContext; // Playwright APIRequestContext
    apiEndpoint: string;
    apiResponse: APIResponse;
    loginValidator: LoginValidator;
}

Given('the API endpoint {string}', async function (this: CustomWorld, endpoint: string) {
    await allure.step(`Set API endpoint: ${endpoint}`, async () => {
        this.apiEndpoint = `${this.config.apiUrl}${endpoint}`; // Assuming config.apiUrl exists
        this.loginValidator = new LoginValidator();
    });
});

When('I send a POST request with username {string} and password {string}', async function (this: CustomWorld, username: string, password: string) {
    await allure.step(`Send POST request to ${this.apiEndpoint} with credentials`, async () => {
        this.apiResponse = await this.request.post(this.apiEndpoint, {
            data: {
                username: username,
                password: password,
            },
            headers: {
                'Content-Type': 'application/json',
            },
        });
    });
});

Then('the API response status should be {int}', async function (this: CustomWorld, expectedStatus: number) {
    await allure.step(`Verify API response status: ${expectedStatus}`, async () => {
        const actualStatus = this.apiResponse.status();
        expect(this.loginValidator.isApiResponseStatusValid(actualStatus, expectedStatus)).toBe(true);
    });
});

Then('the API response should contain an authentication token', async function (this: CustomWorld) {
    await allure.step('Verify API response contains authentication token', async () => {
        const responseBody = await this.apiResponse.json();
        expect(this.loginValidator.doesApiResponseContainAuthToken(responseBody)).toBe(true);
    });
});

Then('the API response should contain an error message {string}', async function (this: CustomWorld, expectedErrorMessage: string) {
    await allure.step(`Verify API response contains error message: "${expectedErrorMessage}"`, async () => {
        const responseBody = await this.apiResponse.json();
        expect(this.loginValidator.isApiErrorMessageValid(responseBody, expectedErrorMessage)).toBe(true);
    });
});