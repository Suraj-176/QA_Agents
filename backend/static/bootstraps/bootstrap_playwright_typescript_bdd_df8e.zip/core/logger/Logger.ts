import winston from 'winston';
import 'winston-daily-rotate-file';
import path from 'path';
import { inspect } from 'util';

/**
 * Regex patterns for sensitive data masking.
 * These patterns are designed to be robust but might need adjustments based on specific data formats.
 */
const SENSITIVE_DATA_PATTERNS = [
  // Credit Card Numbers (13-16 digits, with or without spaces/hyphens)
  /\b(?:\d[ -]*?){13,16}\b/g,
  // Passwords (common field names followed by any characters until a space or end of line)
  /(password|pwd|secret|token|api_key|auth_key)\s*[:=]\s*['"]?([a-zA-Z0-9!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?`~]+)['"]?/gi,
  // Social Security Numbers (XXX-XX-XXXX)
  /\b\d{3}[- ]?\d{2}[- ]?\d{4}\b/g,
  // API Tokens (example: Bearer tokens, JWTs - highly variable, this is a generic attempt)
  /Bearer\s[A-Za-z0-9\-_=]+\.[A-Za-z0-9\-_=]+\.?[A-Za-z0-9\-_=]*|api_token=[A-Za-z0-9]+/g,
  // PAN (Primary Account Number) - similar to credit cards, but can be broader
  /\b(?:PAN|account_number)\s*[:=]\s*['"]?(\d{10,19})['"]?/gi,
];

/**
 * Custom Winston format to mask sensitive data.
 * It iterates through predefined regex patterns and replaces matches with '[REDACTED]'.
 */
const sensitiveDataMasking = winston.format((info) => {
  const message = inspect(info.message, { depth: null, colors: false });
  let maskedMessage = message;

  SENSITIVE_DATA_PATTERNS.forEach(pattern => {
    maskedMessage = maskedMessage.replace(pattern, (match, ...args) => {
      // If it's a key-value pair, redact only the value
      if (pattern.source.includes('[:=]')) {
        const valueToRedact = args[0]; // The captured group for the value
        if (valueToRedact) {
          return match.replace(valueToRedact, '[REDACTED]');
        }
      }
      return '[REDACTED]';
    });
  });

  info.message = maskedMessage;
  return info;
});

/**
 * Logger class implementing a Singleton pattern for centralized logging.
 * It uses Winston for logging and Winston Daily Rotate File for log rotation.
 * Logs are stored in the 'logs' directory, rotated daily, and sensitive data is masked.
 */
class Logger {
  private static instance: Logger;
  private readonly logger: winston.Logger;

  private constructor() {
    const logDir = path.join(process.cwd(), 'logs');

    // Daily rotate file transport for general logs
    const dailyRotateFileTransport = new winston.transports.DailyRotateFile({
      filename: path.join(logDir, 'application-%DATE%.log'),
      datePattern: 'YYYY-MM-DD',
      zippedArchive: true,
      maxSize: '20m', // Max size of 20MB per file
      maxFiles: '14d', // Retain logs for 14 days
      level: 'info',
    });

    // Error log transport (separate file for errors)
    const errorFileTransport = new winston.transports.DailyRotateFile({
      filename: path.join(logDir, 'error-%DATE%.log'),
      datePattern: 'YYYY-MM-DD',
      zippedArchive: true,
      maxSize: '20m',
      maxFiles: '14d',
      level: 'error',
    });

    this.logger = winston.createLogger({
      level: process.env.LOG_LEVEL || 'info', // Default log level
      format: winston.format.combine(
        sensitiveDataMasking(), // Apply sensitive data masking
        winston.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
        winston.format.errors({ stack: true }), // Log stack traces for errors
        winston.format.splat(), // Allows for string interpolation
        winston.format.json() // Use JSON format for file logs
      ),
      transports: [
        dailyRotateFileTransport,
        errorFileTransport,
        // Console transport for development/debugging
        new winston.transports.Console({
          format: winston.format.combine(
            sensitiveDataMasking(), // Apply sensitive data masking to console output too
            winston.format.colorize(), // Colorize console output
            winston.format.timestamp({ format: 'HH:mm:ss' }),
            winston.format.printf(
              (info) => `${info.timestamp} ${info.level}: ${info.message} ${info.stack ? '\n' + info.stack : ''}`
            )
          ),
          level: process.env.CONSOLE_LOG_LEVEL || 'debug', // Console can be more verbose
        }),
      ],
      exitOnError: false, // Do not exit on handled exceptions
    });
  }

  /**
   * Returns the singleton instance of the Logger.
   */
  public static getInstance(): Logger {
    if (!Logger.instance) {
      Logger.instance = new Logger();
    }
    return Logger.instance;
  }

  /**
   * Logs an informational message.
   * @param message The message to log.
   * @param meta Optional metadata.
   */
  public info(message: string, meta?: any): void {
    this.logger.info(message, meta);
  }

  /**
   * Logs a warning message.
   * @param message The message to log.
   * @param meta Optional metadata.
   */
  public warn(message: string, meta?: any): void {
    this.logger.warn(message, meta);
  }

  /**
   * Logs an error message.
   * @param message The message to log.
   * @param error The error object (optional, but recommended for errors).
   * @param meta Optional metadata.
   */
  public error(message: string, error?: Error | unknown, meta?: any): void {
    if (error instanceof Error) {
      this.logger.error(message, { ...meta, error: error.message, stack: error.stack });
    } else if (typeof error === 'string') {
      this.logger.error(message, { ...meta, error: error });
    } else {
      this.logger.error(message, meta);
    }
  }

  /**
   * Logs a debug message.
   * @param message The message to log.
   * @param meta Optional metadata.
   */
  public debug(message: string, meta?: any): void {
    this.logger.debug(message, meta);
  }

  /**
   * Logs a verbose message.
   * @param message The message to log.
   * @param meta Optional metadata.
   */
  public verbose(message: string, meta?: any): void {
    this.logger.verbose(message, meta);
  }
}

export const logger = Logger.getInstance();