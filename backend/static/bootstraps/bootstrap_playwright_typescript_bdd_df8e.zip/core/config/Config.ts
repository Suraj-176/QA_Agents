import dotenv from 'dotenv';
import path from 'path';

// Load environment variables from .env file
dotenv.config({ path: path.resolve(process.cwd(), '.env') });

/**
 * Interface defining the structure of the application configuration.
 */
interface IConfig {
  baseURL: string;
  apiBaseURL: string;
  timeout: number;
  headless: boolean;
  enableAIHealing: boolean;
  allureResultsDir: string;
  logLevel: string;
  consoleLogLevel: string;
  // Add other configuration properties as needed
  sauceDemo: {
    standardUser: string;
    lockedOutUser: string;
    problemUser: string;
    performanceGlitchUser: string;
    password: string;
  };
}

/**
 * Configuration class to manage application settings.
 * It loads values from environment variables with sensible defaults.
 * Implemented as a singleton to ensure a single source of truth for configuration.
 */
class ConfigManager {
  private static instance: ConfigManager;
  private readonly config: IConfig;

  private constructor() {
    this.config = {
      baseURL: process.env.BASE_URL || 'https://www.saucedemo.com',
      apiBaseURL: process.env.API_BASE_URL || 'https://api.example.com',
      timeout: parseInt(process.env.TIMEOUT || '10000', 10), // Default action timeout
      headless: process.env.HEADLESS === 'false' ? false : true, // Default to headless true
      enableAIHealing: process.env.ENABLE_AI_HEALING === 'true', // Default to false
      allureResultsDir: process.env.ALLURE_RESULTS_DIR || 'allure-results',
      logLevel: process.env.LOG_LEVEL || 'info',
      consoleLogLevel: process.env.CONSOLE_LOG_LEVEL || 'debug',
      sauceDemo: {
        standardUser: process.env.SAUCEDEMO_STANDARD_USER || 'standard_user',
        lockedOutUser: process.env.SAUCEDEMO_LOCKED_OUT_USER || 'locked_out_user',
        problemUser: process.env.SAUCEDEMO_PROBLEM_USER || 'problem_user',
        performanceGlitchUser: process.env.SAUCEDEMO_PERFORMANCE_GLITCH_USER || 'performance_glitch_user',
        password: process.env.SAUCEDEMO_PASSWORD || 'secret_sauce',
      },
    };
  }

  /**
   * Returns the singleton instance of the ConfigManager.
   */
  public static getInstance(): ConfigManager {
    if (!ConfigManager.instance) {
      ConfigManager.instance = new ConfigManager();
    }
    return ConfigManager.instance;
  }

  /**
   * Retrieves the entire configuration object.
   */
  public get(): IConfig {
    return this.config;
  }

  /**
   * Retrieves a specific configuration value by key.
   * @param key The key of the configuration property.
   * @returns The value of the configuration property.
   */
  public getProperty<K extends keyof IConfig>(key: K): IConfig[K] {
    return this.config[key];
  }
}

export const Config = ConfigManager.getInstance().get();