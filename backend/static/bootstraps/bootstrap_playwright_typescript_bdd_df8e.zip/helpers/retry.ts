import { Logger } from '@core/logger/Logger';

/**
 * Retries an asynchronous function a specified number of times with an optional delay.
 * This helper is useful for handling flaky operations, network requests, or waiting for eventual consistency.
 *
 * @template T The return type of the asynchronous function.
 * @param fn The asynchronous function to retry.
 * @param retries The maximum number of retries (default: 3).
 * @param delayMs The delay in milliseconds between retries (default: 1000).
 * @param description A descriptive string for the operation being retried, used in logs.
 * @returns A Promise that resolves with the result of the function if successful, or rejects if all retries fail.
 */
export async function retry<T>(
  fn: () => Promise<T>,
  retries: number = 3,
  delayMs: number = 1000,
  description: string = 'operation'
): Promise<T> {
  let attempt = 0;
  while (attempt < retries) {
    try {
      Logger.debug(`Attempt ${attempt + 1}/${retries} for '${description}'...`);
      return await fn();
    } catch (error: any) {
      attempt++;
      Logger.warn(`Attempt ${attempt} for '${description}' failed: ${error.message}`);

      if (attempt < retries) {
        Logger.debug(`Retrying '${description}' in ${delayMs}ms...`);
        await new Promise(resolve => setTimeout(resolve, delayMs));
      } else {
        Logger.error(`All ${retries} attempts for '${description}' failed.`);
        throw error; // Re-throw the last error after all retries are exhausted
      }
    }
  }
  // This line should theoretically not be reached if `throw error` is always executed on final failure,
  // but it's here for type safety and as a fallback.
  throw new Error(`Failed to complete '${description}' after ${retries} attempts.`);
}