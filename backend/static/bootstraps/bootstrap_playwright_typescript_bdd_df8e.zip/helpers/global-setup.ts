import { FullConfig } from '@playwright/test';
import { Logger } from '@core/logger/Logger';
import { Config } from '@core/config/Config';
import path from 'path';
import fs from 'fs';

/**
 * Global setup function for the Playwright test framework.
 * This function runs once before all tests.
 *
 * @param config The Playwright FullConfig object.
 */
async function globalSetup(config: FullConfig) {
  // 1. Initialize the logger
  Logger.info('Starting global setup...');

  // 2. Load configuration
  // Assuming Config.loadConfig() reads environment variables and/or config files
  Config.loadConfig();
  Logger.info('Configuration loaded successfully.');
  Logger.debug(`Base URL: ${Config.get('baseUrl')}`);
  Logger.debug(`Environment: ${Config.get('env')}`);

  // 3. Optional: Clean up previous test run artifacts
  // This helps ensure a clean state for each test run.
  const testResultsDir = path.resolve(process.cwd(), 'test-results');
  if (fs.existsSync(testResultsDir)) {
    Logger.info(`Cleaning up previous test results directory: ${testResultsDir}`);
    try {
      fs.rmSync(testResultsDir, { recursive: true, force: true });
      Logger.info('Previous test results cleaned.');
    } catch (error: any) {
      Logger.error(`Failed to clean up test results directory: ${error.message}`);
    }
  }

  // 4. Optional: Perform other setup tasks
  // - Start a local test server or database if needed.
  // - Authenticate and store a global authentication state (e.g., a token)
  //   if it's shared across many tests and doesn't change.
  //   However, Playwright's `storageState` in `playwright.config.ts` is often preferred for auth.

  Logger.info('Global setup completed successfully.');
}

export default globalSetup;