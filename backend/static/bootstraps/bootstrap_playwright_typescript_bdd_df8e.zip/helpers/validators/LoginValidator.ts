import { APIResponse } from '@playwright/test';
import { Logger } from '../../core/logger/Logger'; // Assuming Logger path

/**
 * LoginValidator class implements the "Zero Assertions" policy.
 * Its methods return boolean values or throw errors,
 * leaving the actual 'expect' assertions to the step definitions.
 */
export class LoginValidator {
    private readonly logger: Logger;

    constructor() {
        this.logger = new Logger(LoginValidator.name);
    }

    /**
     * Validates if the actual UI login success message matches the expected message.
     * @param {string | null} actualMessage - The actual message retrieved from the UI.
     * @param {string} expectedMessage - The message expected to be displayed.
     * @returns {boolean} True if the messages match (case-insensitive and trimmed), false otherwise.
     */
    isLoginSuccessMessageValid(actualMessage: string | null, expectedMessage: string): boolean {
        this.logger.debug(`Validating UI success message. Actual: "${actualMessage}", Expected: "${expectedMessage}"`);
        if (!actualMessage) {
            this.logger.warn('Actual success message is null or empty.');
            return false;
        }
        return actualMessage.trim().toLowerCase().includes(expectedMessage.trim().toLowerCase());
    }

    /**
     * Validates if the actual UI login error message matches the expected message.
     * @param {string | null} actualMessage - The actual message retrieved from the UI.
     * @param {string} expectedMessage - The message expected to be displayed.
     * @returns {boolean} True if the messages match (case-insensitive and trimmed), false otherwise.
     */
    isLoginErrorMessageValid(actualMessage: string | null, expectedMessage: string): boolean {
        this.logger.debug(`Validating UI error message. Actual: "${actualMessage}", Expected: "${expectedMessage}"`);
        if (!actualMessage) {
            this.logger.warn('Actual error message is null or empty.');
            return false;
        }
        return actualMessage.trim().toLowerCase().includes(expectedMessage.trim().toLowerCase());
    }

    /**
     * Validates if the API response status matches the expected status.
     * @param {number} actualStatus - The actual HTTP status code from the API response.
     * @param {number} expectedStatus - The expected HTTP status code.
     * @returns {boolean} True if the statuses match, false otherwise.
     */
    isApiResponseStatusValid(actualStatus: number, expectedStatus: number): boolean {
        this.logger.debug(`Validating API response status. Actual: ${actualStatus}, Expected: ${expectedStatus}`);
        return actualStatus === expectedStatus;
    }

    /**
     * Checks if the API response body contains an authentication token.
     * This assumes the token is typically a string and named 'token' or 'accessToken'.
     * @param {any} responseBody - The parsed JSON body of the API response.
     * @returns {boolean} True if a token is found and is a non-empty string, false otherwise.
     */
    doesApiResponseContainAuthToken(responseBody: any): boolean {
        this.logger.debug('Validating API response for authentication token.');
        const token = responseBody?.token || responseBody?.accessToken;
        return typeof token === 'string' && token.length > 0;
    }

    /**
     * Validates if the API response body contains a specific error message.
     * This assumes error messages are typically in a 'message' or 'error' field.
     * @param {any} responseBody - The parsed JSON body of the API response.
     * @param {string} expectedErrorMessage - The error message expected in the response.
     * @returns {boolean} True if the error message is found and matches (case-insensitive), false otherwise.
     */
    isApiErrorMessageValid(responseBody: any, expectedErrorMessage: string): boolean {
        this.logger.debug(`Validating API error message. Expected: "${expectedErrorMessage}"`);
        const errorMessage = responseBody?.message || responseBody?.error;
        if (!errorMessage) {
            this.logger.warn('API response body does not contain an error message field.');
            return false;
        }
        return String(errorMessage).trim().toLowerCase().includes(expectedErrorMessage.trim().toLowerCase());
    }
}