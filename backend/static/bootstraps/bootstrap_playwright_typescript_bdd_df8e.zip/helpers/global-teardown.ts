import { FullConfig } from '@playwright/test';
import { Logger } from '@core/logger/Logger';

/**
 * Global teardown function for the Playwright test framework.
 * This function runs once after all tests have completed.
 *
 * @param config The Playwright FullConfig object.
 */
async function globalTeardown(config: FullConfig) {
  Logger.info('Starting global teardown...');

  // 1. Optional: Clean up any resources created during global setup
  //    e.g., stop a local test server, close database connections.

  // 2. Optional: Generate custom reports or aggregate data
  //    (Most reporting is handled by Playwright reporters, but custom aggregation can go here).

  Logger.info('Global teardown completed.');
}

export default globalTeardown;