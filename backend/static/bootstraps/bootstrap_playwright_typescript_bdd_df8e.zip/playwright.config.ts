import { defineConfig, devices, PlaywrightTestConfig } from '@playwright/test';
import { defineBddConfig } from 'playwright-bdd';
import dotenv from 'dotenv';
import path from 'path';

// Load environment variables from .env file
dotenv.config({ path: path.resolve(__dirname, '.env') });

// Define BDD configuration
const testDir = defineBddConfig({
  paths: ['features/**/*.feature'], // Path to your Gherkin feature files
  require: ['steps/**/*.ts'], // Path to your step definition files
  // You can add more options here, e.g., tags, publish, etc.
});

/**
 * Read environment variables for configuration.
 * Provide default values for robustness.
 */
const BASE_URL = process.env.BASE_URL || 'https://www.saucedemo.com';
const API_BASE_URL = process.env.API_BASE_URL || 'https://api.example.com';
const HEADLESS = process.env.HEADLESS === 'false' ? false : true;
const RETRIES = parseInt(process.env.RETRIES || '0', 10);
const WORKERS = parseInt(process.env.WORKERS || 'undefined', 10); // undefined means Playwright decides
const TRACE = process.env.TRACE || 'off'; // 'on', 'off', 'retain-on-failure', 'on-first-retry'
const VIEWPORT_WIDTH = parseInt(process.env.VIEWPORT_WIDTH || '1920', 10);
const VIEWPORT_HEIGHT = parseInt(process.env.VIEWPORT_HEIGHT || '1080', 10);
const ACTION_TIMEOUT = parseInt(process.env.ACTION_TIMEOUT || '10000', 10);
const NAVIGATION_TIMEOUT = parseInt(process.env.NAVIGATION_TIMEOUT || '30000', 10);
const ALLURE_RESULTS_DIR = process.env.ALLURE_RESULTS_DIR || 'allure-results';

/**
 * See https://playwright.dev/docs/test-configuration.
 */
const config: PlaywrightTestConfig = {
  // BDD specific test directory configuration
  testDir,
  /* Run tests in files in parallel */
  fullyParallel: true,
  /* Fail the build on CI if you accidentally left test.only in the source code. */
  forbidOnly: !!process.env.CI,
  /* Retry on CI only */
  retries: process.env.CI ? RETRIES : 0,
  /* Opt out of parallel tests on CI. */
  workers: process.env.CI ? WORKERS : undefined,
  /* Reporter to use. See https://playwright.dev/docs/test-reporters */
  reporter: [
    ['list'],
    ['html', { open: 'never' }], // Keep HTML report, but don't open automatically
    ['allure-playwright', {
      outputFolder: ALLURE_RESULTS_DIR,
      detail: true,
      suiteTitle: true,
      categories: [
        { name: 'Flaky tests', matchedStatuses: ['failed', 'broken'], percentage: true },
        { name: 'Passed tests', matchedStatuses: ['passed'], percentage: true },
      ],
    }],
  ],
  /* Shared settings for all the projects below. See https://playwright.dev/docs/api/class-testoptions. */
  use: {
    /* Base URL to use in actions like `await page.goto('/')`. */
    baseURL: BASE_URL,
    /* Collect trace when retrying the failed test. See https://playwright.dev/docs/trace-viewer */
    trace: TRACE,
    /* Headless mode for browsers. */
    headless: HEADLESS,
    /* Viewport size for browsers. */
    viewport: { width: VIEWPORT_WIDTH, height: VIEWPORT_HEIGHT },
    /* Action timeout for Playwright actions. */
    actionTimeout: ACTION_TIMEOUT,
    /* Navigation timeout for page navigations. */
    navigationTimeout: NAVIGATION_TIMEOUT,
    /* Ignore HTTPS errors for local development or specific environments. */
    ignoreHTTPSErrors: true,
    /* Capture screenshot on failure. */
    screenshot: 'only-on-failure',
    /* Record video on failure. */
    video: 'retain-on-failure',
    /* API Base URL for API tests */
    apiBaseURL: API_BASE_URL,
  },

  /* Configure projects for major browsers */
  projects: [
    {
      name: 'chromium',
      use: { ...devices['Desktop Chrome'] },
    },

    {
      name: 'firefox',
      use: { ...devices['Desktop Firefox'] },
    },

    {
      name: 'webkit',
      use: { ...devices['Desktop Safari'] },
    },

    /* Test against mobile viewports. */
    // {
    //   name: 'Mobile Chrome',
    //   use: { ...devices['Pixel 5'] },
    // },
    // {
    //   name: 'Mobile Safari',
    //   use: { ...devices['iPhone 12'] },
    // },

    /* Test against branded browsers. */
    // {
    //   name: 'Microsoft Edge',
    //   use: { ...devices['Desktop Edge'], channel: 'msedge' },
    // },
    // {
    //   name: 'Google Chrome',
    //   use: { ...devices['Desktop Chrome'], channel: 'chrome' },
    // },
  ],

  /* Folder for test artifacts relative to the configuration file. */
  outputDir: 'test-results',

  /* Global setup and teardown for the entire test run. */
  // globalSetup: require.resolve('./global-setup'),
  // globalTeardown: require.resolve('./global-teardown'),
};

export default defineConfig(config);