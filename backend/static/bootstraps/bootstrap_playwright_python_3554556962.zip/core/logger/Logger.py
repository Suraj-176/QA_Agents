import logging
import re
import threading
import allure
from typing import Any, Dict, List, Optional

class SecureLogger:
    """
    A Singleton logger class designed for enterprise-grade applications,
    specifically for banking platforms. It automatically masks sensitive
    information before logging to ensure data security and compliance.

    Sensitive data patterns include:
    - Credit Card Numbers (PANs)
    - CVV/CVC
    - Passwords
    - API Tokens/Keys
    - Social Security Numbers (SSN)
    - Bank Account Numbers
    - Routing Numbers
    - Email Addresses (basic masking)
    """

    _instance = None
    _lock = threading.Lock()
    _initialized = False

    # Regex patterns for sensitive data masking
    # These patterns are designed to be robust but may need adjustment
    # based on specific data formats in your application.
    SENSITIVE_PATTERNS: List[re.Pattern] = [
        # Credit Card Numbers (13-19 digits, common prefixes)
        re.compile(r'\b(?:4[0-9]{12}(?:[0-9]{3})?|5[1-5][0-9]{14}|6(?:011|5[0-9]{2})[0-9]{12}|3[47][0-9]{13}|3(?:0[0-5]|[68][0-9])[0-9]{11}|(?:2131|1800|35\d{3})\d{11})\b'),
        # CVV/CVC (3 or 4 digits)
        re.compile(r'\b\d{3,4}\b(?!\d)'),
        # Passwords (common field names)
        re.compile(r'(password|pwd|secret|passphrase|auth_token|api_key|access_token|refresh_token|bearer)\s*[:=]\s*[\'"]?([^\s\'"]+)[\'"]?', re.IGNORECASE),
        # Basic token/key patterns (e.g., "token": "xyz", "key=abc")
        re.compile(r'(token|key|jwt|apikey|bearer)\s*[:=]\s*[\'"]?([a-zA-Z0-9\-_]+\.[a-zA-Z0-9\-_]+\.[a-zA-Z0-9\-_]+|[a-f0-9]{32,64})\b', re.IGNORECASE),
        # Social Security Numbers (XXX-XX-XXXX)
        re.compile(r'\b\d{3}-\d{2}-\d{4}\b'),
        # Bank Account Numbers (example: 10-12 digits)
        re.compile(r'\b\d{10,12}\b'),
        # Routing Numbers (9 digits)
        re.compile(r'\b\d{9}\b'),
        # Email Addresses (basic masking, e.g., user@domain.com -> u***r@d***n.com)
        re.compile(r'([a-zA-Z0-9._%+-]+)@([a-zA-Z0-9.-]+)\.([a-zA-Z]{2,})')
    ]

    MASK_STRING = "***MASKED***"

    def __new__(cls, *args, **kwargs):
        """
        Ensures only one instance of SecureLogger is created (Singleton pattern).
        """
        if not cls._instance:
            with cls._lock:
                if not cls._instance:
                    cls._instance = super(SecureLogger, cls).__new__(cls)
        return cls._instance

    def __init__(self):
        """
        Initializes the logger, setting up handlers and formatters.
        This ensures initialization happens only once.
        """
        if self._initialized:
            return

        self.logger = logging.getLogger(__name__)
        self.logger.setLevel(logging.INFO) # Default level, can be configured via env

        # Prevent adding multiple handlers if __init__ is called multiple times
        if not self.logger.handlers:
            # Console handler
            console_handler = logging.StreamHandler()
            console_handler.setFormatter(self._SecureFormatter())
            self.logger.addHandler(console_handler)

            # File handler (optional, uncomment for file logging)
            # file_handler = logging.FileHandler("automation.log")
            # file_handler.setFormatter(self._SecureFormatter())
            # self.logger.addHandler(file_handler)

        self._initialized = True

    class _SecureFormatter(logging.Formatter):
        """
        Custom formatter to mask sensitive data in log records.
        """
        def __init__(self, fmt: Optional[str] = None, datefmt: Optional[str] = None):
            super().__init__(fmt or '%(asctime)s - %(levelname)s - %(message)s', datefmt)

        def format(self, record: logging.LogRecord) -> str:
            """
            Formats the log record and applies masking to sensitive data.
            """
            original_message = super().format(record)
            masked_message = self._mask_sensitive_data(original_message)
            return masked_message

        def _mask_sensitive_data(self, text: str) -> str:
            """
            Applies masking to the given text using predefined regex patterns.
            """
            for pattern in SecureLogger.SENSITIVE_PATTERNS:
                # Special handling for email to mask parts of it
                if pattern == SecureLogger.SENSITIVE_PATTERNS[-1]: # Assuming email is the last pattern
                    text = pattern.sub(self._mask_email, text)
                else:
                    text = pattern.sub(SecureLogger.MASK_STRING, text)
            return text

        def _mask_email(self, match: re.Match) -> str:
            """
            Masks parts of an email address.
            e.g., user@domain.com -> u***r@d***n.com
            """
            user_part = match.group(1)
            domain_part = match.group(2)
            tld_part = match.group(3)

            masked_user = user_part[0] + SecureLogger.MASK_STRING + user_part[-1] if len(user_part) > 2 else SecureLogger.MASK_STRING
            masked_domain = domain_part[0] + SecureLogger.MASK_STRING + domain_part[-1] if len(domain_part) > 2 else SecureLogger.MASK_STRING

            return f"{masked_user}@{masked_domain}.{tld_part}"

    @allure.step("Log DEBUG: {message}")
    def debug(self, message: str, *args: Any, **kwargs: Any) -> None:
        """Logs a debug message with Allure step traceability."""
        self.logger.debug(message, *args, **kwargs)

    @allure.step("Log INFO: {message}")
    def info(self, message: str, *args: Any, **kwargs: Any) -> None:
        """Logs an info message with Allure step traceability."""
        self.logger.info(message, *args, **kwargs)

    @allure.step("Log WARNING: {message}")
    def warning(self, message: str, *args: Any, **kwargs: Any) -> None:
        """Logs a warning message with Allure step traceability."""
        self.logger.warning(message, *args, **kwargs)

    @allure.step("Log ERROR: {message}")
    def error(self, message: str, *args: Any, **kwargs: Any) -> None:
        """Logs an error message with Allure step traceability."""
        self.logger.error(message, *args, **kwargs)

    @allure.step("Log CRITICAL: {message}")
    def critical(self, message: str, *args: Any, **kwargs: Any) -> None:
        """Logs a critical message with Allure step traceability."""
        self.logger.critical(message, *args, **kwargs)

# Global instance of the secure logger
logger = SecureLogger()