import os
import sys
import asyncio
import shutil
from pathlib import Path

# Add the project root to the sys.path to allow importing core modules
# Assuming the project root is one level up from 'helpers'
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

# Import the Logger from Phase 1
from core.logger.Logger import Logger

# Initialize the logger globally for setup/teardown scripts.
logger = Logger(__name__).get_logger()

async def global_teardown():
    """
    This asynchronous function runs once after all tests have completed.
    It's responsible for cleaning up global resources or state created during setup.
    Examples include:
    - Deleting temporary directories and files (e.g., test artifacts).
    - Closing shared database connections or API clients.
    - Unsetting environment variables.
    - Generating final reports or sending notifications (though Playwright reporters handle much of this).
    """
    logger.info("🧹 Starting global teardown...")

    # --- Example: Clean up the test artifacts directory ---
    # This removes all files and subdirectories created during the test run.
    artifacts_dir = project_root / "test-artifacts"
    if artifacts_dir.exists():
        try:
            shutil.rmtree(artifacts_dir)
            logger.info(f"Cleaned up test artifacts directory: {artifacts_dir}")
        except OSError as e:
            logger.error(f"Error cleaning up test artifacts directory {artifacts_dir}: {e}")
    else:
        logger.info(f"Test artifacts directory not found, no cleanup needed: {artifacts_dir}")

    # --- Example: Unset environment variables set during setup ---
    if "PLAYWRIGHT_TEST_ENV" in os.environ:
        del os.environ["PLAYWRIGHT_TEST_ENV"]
        logger.info("Unset environment variable PLAYWRIGHT_TEST_ENV")

    # --- Example: Clean up any global storage state file ---
    # storage_state_path = artifacts_dir / "storageState.json"
    # if storage_state_path.exists():
    #     try:
    #         os.remove(storage_state_path)
    #         logger.info(f"Removed global storage state file: {storage_state_path}")
    #     except OSError as e:
    #         logger.error(f"Error removing global storage state file {storage_state_path}: {e}")

    logger.info("🗑️ Global teardown complete.")

if __name__ == "__main__":
    # This allows running the teardown script independently for testing purposes.
    # It will execute the global_teardown function.
    asyncio.run(global_teardown())