import re
from playwright.sync_api import Page, Response
from core.logger.Logger import Logger
# Assuming LoginPage is available for UI-specific checks
from src.pages.loginPage import LoginPage

class LoginValidator:
    """
    A validator class for login-related assertions, adhering to the Zero Assertions policy.
    Methods return boolean results or specific data points, allowing the calling step
    definition to perform the actual assertion.
    """

    logger = Logger().get_logger()

    @staticmethod
    def validate_page_title(page: Page, expected_title: str) -> bool:
        """
        Validates if the current page title matches the expected title.
        Returns True if titles match, False otherwise.
        """
        actual_title = page.title()
        LoginValidator.logger.info(f"Validating page title. Expected: '{expected_title}', Actual: '{actual_title}'")
        return actual_title == expected_title

    @staticmethod
    def is_ui_login_successful(login_page: LoginPage) -> bool:
        """
        Checks if the UI login was successful by verifying the presence of the products page.
        Returns True if successful, False otherwise.
        """
        is_successful = login_page.is_products_page_displayed()
        LoginValidator.logger.info(f"UI Login success check: {'Successful' if is_successful else 'Failed'}")
        return is_successful

    @staticmethod
    def is_ui_error_message_displayed(error_message: str) -> bool:
        """
        Checks if a UI error message is displayed and is not empty.
        Returns True if an error message is present, False otherwise.
        """
        is_displayed = bool(error_message)
        LoginValidator.logger.info(f"UI Error message check: {'Displayed' if is_displayed else 'Not Displayed'}")
        return is_displayed

    @staticmethod
    def validate_api_status_code(response: Response, expected_status_code: int) -> bool:
        """
        Validates if the API response status code matches the expected status code.
        Returns True if status codes match, False otherwise.
        """
        actual_status_code = response.status
        LoginValidator.logger.info(f"Validating API status code. Expected: {expected_status_code}, Actual: {actual_status_code}")
        return actual_status_code == expected_status_code

    @staticmethod
    def validate_api_token_presence(response_json: dict) -> bool:
        """
        Validates if the API response JSON contains an 'accessToken' or 'token' field
        and if its value is a non-empty string.
        Returns True if a token is found, False otherwise.
        """
        token_keys = ['accessToken', 'token', 'jwt'] # Common token keys
        for key in token_keys:
            token = response_json.get(key)
            if isinstance(token, str) and token:
                LoginValidator.logger.info(f"API token found with key '{key}'.")
                return True
        LoginValidator.logger.warning("No valid API token found in response JSON.")
        return False

    @staticmethod
    def validate_api_error_message(response_json: dict, expected_message_regex: str) -> bool:
        """
        Validates if the API response JSON contains an error message matching a regex.
        Returns True if a matching error message is found, False otherwise.
        """
        error_message = response_json.get('message') or response_json.get('error')
        if isinstance(error_message, str):
            match = re.search(expected_message_regex, error_message, re.IGNORECASE)
            LoginValidator.logger.info(f"API error message validation. Expected regex: '{expected_message_regex}', Actual: '{error_message}', Match: {bool(match)}")
            return bool(match)
        LoginValidator.logger.warning("No error message found in API response JSON for validation.")
        return False