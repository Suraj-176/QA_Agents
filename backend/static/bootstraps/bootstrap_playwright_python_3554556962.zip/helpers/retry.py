import time
import functools
import asyncio
from typing import Callable, Type, Tuple, Any, Union

# Attempt to import the custom Logger from core.
# If the framework's path isn't set up (e.g., running retry.py in isolation),
# fall back to standard Python logging.
try:
    from core.logger.Logger import Logger
    logger = Logger(__name__).get_logger()
except ImportError:
    import logging
    logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    logger = logging.getLogger(__name__)
    logger.warning("Could not import core.logger.Logger. Using standard logging for retry helper.")


def retry(
    max_attempts: int = 3,
    delay_seconds: float = 1.0,
    exceptions_to_catch: Union[Type[Exception], Tuple[Type[Exception], ...]] = Exception,
    log_retries: bool = True
) -> Callable:
    """
    A decorator to retry a function (synchronous or asynchronous) multiple times
    if it raises a specified exception.

    Args:
        max_attempts (int): The maximum number of times to attempt the function call.
        delay_seconds (float): The delay in seconds between retries.
        exceptions_to_catch (Union[Type[Exception], Tuple[Type[Exception], ...]]):
            The exception type(s) to catch and trigger a retry. Defaults to Exception.
        log_retries (bool): Whether to log retry attempts using the configured logger.

    Returns:
        Callable: The decorated function, which will include retry logic.
    """
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
            """Wrapper for asynchronous functions."""
            for attempt in range(1, max_attempts + 1):
                try:
                    return await func(*args, **kwargs)
                except exceptions_to_catch as e:
                    if attempt < max_attempts:
                        if log_retries:
                            logger.warning(
                                f"Attempt {attempt}/{max_attempts} failed for '{func.__name__}': {e.__class__.__name__}: {e}. "
                                f"Retrying in {delay_seconds} seconds..."
                            )
                        await asyncio.sleep(delay_seconds)
                    else:
                        if log_retries:
                            logger.error(
                                f"Attempt {attempt}/{max_attempts} failed for '{func.__name__}': {e.__class__.__name__}: {e}. "
                                "No more retries left."
                            )
                        raise  # Re-raise the last exception if max attempts reached
            # This line should ideally not be reached, but included for type completeness.
            raise RuntimeError(f"Unexpected state: {func.__name__} did not return or raise after retries.")

        @functools.wraps(func)
        def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
            """Wrapper for synchronous functions."""
            for attempt in range(1, max_attempts + 1):
                try:
                    return func(*args, **kwargs)
                except exceptions_to_catch as e:
                    if attempt < max_attempts:
                        if log_retries:
                            logger.warning(
                                f"Attempt {attempt}/{max_attempts} failed for '{func.__name__}': {e.__class__.__name__}: {e}. "
                                f"Retrying in {delay_seconds} seconds..."
                            )
                        time.sleep(delay_seconds)
                    else:
                        if log_retries:
                            logger.error(
                                f"Attempt {attempt}/{max_attempts} failed for '{func.__name__}': {e.__class__.__name__}: {e}. "
                                "No more retries left."
                            )
                        raise  # Re-raise the last exception if max attempts reached
            # This line should ideally not be reached, but included for type completeness.
            raise RuntimeError(f"Unexpected state: {func.__name__} did not return or raise after retries.")

        # Determine if the function is asynchronous and return the appropriate wrapper
        if asyncio.iscoroutinefunction(func):
            return async_wrapper
        else:
            return sync_wrapper

    return decorator

# --- Example Usage (for testing the retry decorator independently) ---
if __name__ == "__main__":
    # Ensure logger is set up for standalone execution if not already.
    if 'logger' not in locals() or logger.name == __name__:
        import logging
        logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        logger = logging.getLogger(__name__)

    # --- Test Case 1: Synchronous function that succeeds on retry ---
    sync_call_count = 0
    @retry(max_attempts=3, delay_seconds=0.1, exceptions_to_catch=ValueError)
    def flaky_sync_function():
        global sync_call_count
        sync_call_count += 1
        logger.info(f"  Sync function called, attempt {sync_call_count}")
        if sync_call_count < 3:
            raise ValueError("Simulated sync failure!")
        return "Sync Success!"

    logger.info("\n--- Testing Synchronous Function (Succeeds) ---")
    try:
        result_sync = flaky_sync_function()
        logger.info(f"Result: {result_sync}")
    except Exception as e:
        logger.error(f"Test failed unexpectedly: {e}")

    # --- Test Case 2: Asynchronous function that succeeds on retry ---
    async_call_count = 0
    @retry(max_attempts=3, delay_seconds=0.1, exceptions_to_catch=RuntimeError)
    async def flaky_async_function():
        global async_call_count
        async_call_count += 1
        logger.info(f"  Async function called, attempt {async_call_count}")
        if async_call_count < 3:
            raise RuntimeError("Simulated async failure!")
        return "Async Success!"

    logger.info("\n--- Testing Asynchronous Function (Succeeds) ---")
    try:
        async def run_async_test():
            result_async = await flaky_async_function()
            logger.info(f"Result: {result_async}")
        asyncio.run(run_async_test())
    except Exception as e:
        logger.error(f"Test failed unexpectedly: {e}")

    # --- Test Case 3: Synchronous function that always fails ---
    fail_sync_call_count = 0
    @retry(max_attempts=2, delay_seconds=0.1, exceptions_to_catch=ConnectionError)
    def always_fail_sync_function():
        global fail_sync_call_count
        fail_sync_call_count += 1
        logger.info(f"  Always fail sync function called, attempt {fail_sync_call_count}")
        raise ConnectionError("Simulated persistent connection error!")

    logger.info("\n--- Testing Synchronous Function (Always Fails) ---")
    try:
        always_fail_sync_function()
    except ConnectionError as e:
        logger.error(f"Caught expected exception: {e}")
    except Exception as e:
        logger.error(f"Caught unexpected exception: {e}")

    # --- Test Case 4: Asynchronous function that always fails ---
    fail_async_call_count = 0
    @retry(max_attempts=2, delay_seconds=0.1, exceptions_to_catch=TimeoutError)
    async def always_fail_async_function():
        global fail_async_call_count
        fail_async_call_count += 1
        logger.info(f"  Always fail async function called, attempt {fail_async_call_count}")
        raise TimeoutError("Simulated persistent timeout error!")

    logger.info("\n--- Testing Asynchronous Function (Always Fails) ---")
    try:
        async def run_always_fail_async_test():
            await always_fail_async_function()
        asyncio.run(run_always_fail_async_test())
    except TimeoutError as e:
        logger.error(f"Caught expected exception: {e}")
    except Exception as e:
        logger.error(f"Caught unexpected exception: {e}")