import os
import sys
import asyncio
from pathlib import Path

# Add the project root to the sys.path to allow importing core modules
# Assuming the project root is one level up from 'helpers'
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

# Import the Logger from Phase 1
from core.logger.Logger import Logger

# Initialize the logger globally for setup/teardown scripts.
# This logger instance will be used for setup/teardown specific logs.
# Test-specific logs will typically use their own logger instances.
logger = Logger(__name__).get_logger()

async def global_setup():
    """
    This asynchronous function runs once before all tests.
    It's responsible for setting up global resources or state for the entire test run.
    Examples include:
    - Initializing shared resources (e.g., database connections, API clients).
    - Performing a global login and saving authentication state for all tests.
    - Creating necessary directories for test artifacts (screenshots, videos, reports).
    - Setting up environment variables.
    """
    logger.info("🚀 Starting global setup...")

    # --- Example: Create a directory for test artifacts ---
    # This directory will store screenshots, videos, reports, and other test outputs.
    artifacts_dir = project_root / "test-artifacts"
    if not artifacts_dir.exists():
        artifacts_dir.mkdir(parents=True, exist_ok=True)
        logger.info(f"Created test artifacts directory: {artifacts_dir}")
    else:
        logger.info(f"Test artifacts directory already exists: {artifacts_dir}")

    # --- Example: Set an environment variable ---
    # This variable can be accessed by tests to determine the test environment or configuration.
    os.environ["PLAYWRIGHT_TEST_ENV"] = "STAGING"
    logger.info(f"Set environment variable PLAYWRIGHT_TEST_ENV={os.environ['PLAYWRIGHT_TEST_ENV']}")

    # --- Example: Perform a global login and save storage state ---
    # This is useful if all tests require a pre-authenticated session.
    # The storage state can then be loaded by individual test contexts.
    # Note: For robust, isolated tests, consider performing login per test or worker.
    # from playwright.async_api import async_playwright
    # try:
    #     async with async_playwright() as p:
    #         browser = await p.chromium.launch()
    #         page = await browser.new_page()
    #         await page.goto("https://example.com/login")
    #         await page.fill("#username", "admin")
    #         await page.fill("#password", "password")
    #         await page.click("#login-button")
    #         await page.context.storage_state(path=artifacts_dir / "storageState.json")
    #         await browser.close()
    #         logger.info("Global login performed and storage state saved to 'test-artifacts/storageState.json'.")
    # except Exception as e:
    #     logger.error(f"Failed to perform global login during setup: {e}")
    #     # Depending on criticality, you might want to raise an exception to stop the test run
    #     # raise

    logger.info("✅ Global setup complete.")

if __name__ == "__main__":
    # This allows running the setup script independently for testing purposes.
    # It will execute the global_setup function.
    asyncio.run(global_setup())