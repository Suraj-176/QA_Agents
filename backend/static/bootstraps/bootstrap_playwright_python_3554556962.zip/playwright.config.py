import os
from playwright.sync_api import Playwright, sync_playwright, expect
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

# Base URL for UI tests, can be overridden by environment variable
BASE_URL = os.getenv("BASE_URL", "http://localhost:8080")
# Base URL for API tests, can be overridden by environment variable
API_BASE_URL = os.getenv("API_BASE_URL", "http://localhost:5000/api/v1")

def pytest_playwright_before_run(config, playwright: Playwright):
    """
    Hook to configure Playwright before tests run.
    """
    # Example: Set up global browser context options if needed
    pass

def pytest_playwright_after_run(config, playwright: Playwright):
    """
    Hook to clean up Playwright after tests run.
    """
    pass

def pytest_configure(config):
    """
    Pytest hook for initial configuration.
    """
    # Add custom markers if necessary
    config.addinivalue_line("markers", "ui: mark test as UI test")
    config.addinivalue_line("markers", "api: mark test as API test")

# Playwright configuration dictionary
# This will be picked up by pytest-playwright
# For more details: https://playwright.dev/python/docs/test-runners
pytest_plugins = ["pytest_playwright"]

def playwright_config():
    """
    Returns the Playwright configuration dictionary.
    This function is called by pytest-playwright.
    """
    return {
        "test_dir": "tests",  # Base directory for all tests
        "timeout": 60000,     # Global timeout for tests (60 seconds)
        "retries": 1,         # Number of times to retry failed tests
        "workers": os.cpu_count() or 1, # Number of parallel workers
        "output_dir": "test-results/", # Directory for test artifacts (screenshots, traces)
        "use": {
            "headless": os.getenv("HEADLESS", "true").lower() == "true", # Run browsers in headless mode
            "viewport": {"width": 1920, "height": 1080}, # Default viewport size
            "action_timeout": 10000, # Timeout for individual actions (e.g., click, fill)
            "navigation_timeout": 30000, # Timeout for page navigation
            "trace": "on-first-retry", # Record trace only when retrying a test
            "screenshot": "only-on-failure", # Take screenshot only on failure
            "video": "retain-on-failure", # Retain video only on failure
            "baseURL": BASE_URL, # Base URL for UI tests, used by page.goto('/')
            "extraHTTPHeaders": { # Example: Global headers for all requests
                "X-Framework-Version": "1.0",
                "User-Agent": "Playwright-Test-Framework/1.0"
            }
        },
        "projects": [
            {
                "name": "UI-Chrome",
                "test_dir": "tests/ui", # Specific test directory for UI tests
                "use": {
                    "browser_name": "chromium",
                    "baseURL": BASE_URL,
                    "viewport": {"width": 1920, "height": 1080},
                    "launch_options": {
                        "args": ["--start-maximized"] # Example: Start browser maximized
                    }
                },
                "grep_invert": r"@api", # Exclude tests marked with @api
            },
            {
                "name": "UI-Firefox",
                "test_dir": "tests/ui",
                "use": {
                    "browser_name": "firefox",
                    "baseURL": BASE_URL,
                    "viewport": {"width": 1920, "height": 1080},
                },
                "grep_invert": r"@api",
            },
            {
                "name": "API",
                "test_dir": "tests/api", # Specific test directory for API tests
                "use": {
                    "baseURL": API_BASE_URL, # Base URL for API tests
                    "browser_name": "chromium", # Browser is still required by Playwright, but not used for API calls directly
                    "headless": True,
                    "viewport": None, # No viewport needed for API tests
                },
                "grep": r"@api", # Only include tests marked with @api
            }
        ],
        "reporter": [
            ["list"], # Console reporter
            ["html", {"outputFolder": "playwright-report", "open": "never"}], # Playwright HTML reporter
            ["allure-pytest/reporter", {"resultsDir": "allure-results"}] # Allure reporter
        ],
        "metadata": { # Custom metadata for reports
            "project": "Global Banking Platform",
            "environment": os.getenv("ENV", "DEV"),
            "framework": "Playwright-Python"
        }
    }

# This is the entry point for pytest-playwright to discover the config
# It must be a dictionary or a callable returning a dictionary.
# We use a callable to allow for dynamic configuration based on environment variables.
# The actual config object is returned by the function `playwright_config`
# which is then used by pytest-playwright.
# For direct execution of Playwright tests (e.g., `playwright test`),
# this file would typically be named `playwright.config.ts` or `playwright.config.js`.
# For Python with pytest-playwright, the configuration is often embedded or
# provided via a fixture. The above structure is a common way to provide it.
# The `playwright_config` function will be implicitly discovered by `pytest-playwright`.
# If you run `pytest` directly, it will use this configuration.
# If you run `playwright test` (which is not the primary way for Python frameworks),
# it would look for a `playwright.config.py` file.
# For this setup, `pytest` is the primary runner.