from playwright.sync_api import Page
from core.logger.Logger import Logger
# Assuming BasePage exists and provides self._page and self.logger
from src.pages.basePage import BasePage # Assuming basePage.py exists in src/pages

class LoginPage(BasePage):
    """
    Page Object Model for the Login Page.
    Provides methods to interact with login elements and navigate.
    """

    # Locators
    USERNAME_INPUT = "#user-name"
    PASSWORD_INPUT = "#password"
    LOGIN_BUTTON = "#login-button"
    ERROR_MESSAGE = "[data-test='error']"
    PRODUCTS_PAGE_TITLE = ".title" # Example locator for a successful login page

    def __init__(self, page: Page):
        super().__init__(page)
        self.logger = Logger().get_logger()
        self.url = "https://www.saucedemo.com/" # Example login URL

    @Logger.log_method_entry_exit
    def navigate(self) -> 'LoginPage':
        """Navigates to the login page."""
        self.logger.info(f"Navigating to login page: {self.url}")
        self._page.goto(self.url)
        return self

    @Logger.log_method_entry_exit
    def enter_username(self, username: str) -> 'LoginPage':
        """Enters the given username into the username field."""
        self.logger.info(f"Entering username: '{username}'")
        self._page.fill(self.USERNAME_INPUT, username)
        return self

    @Logger.log_method_entry_exit
    def enter_password(self, password: str) -> 'LoginPage':
        """Enters the given password into the password field."""
        self.logger.info(f"Entering password: '{'*' * len(password)}'") # Mask password in logs
        self._page.fill(self.PASSWORD_INPUT, password)
        return self

    @Logger.log_method_entry_exit
    def click_login_button(self) -> 'LoginPage':
        """Clicks the login button."""
        self.logger.info("Clicking login button.")
        self._page.click(self.LOGIN_BUTTON)
        return self

    @Logger.log_method_entry_exit
    def get_error_message(self) -> str:
        """Returns the text of the error message, if present."""
        self.logger.info("Attempting to retrieve error message.")
        if self._page.locator(self.ERROR_MESSAGE).is_visible():
            error_text = self._page.locator(self.ERROR_MESSAGE).text_content()
            self.logger.warning(f"Login error message found: '{error_text}'")
            return error_text
        self.logger.info("No login error message found.")
        return ""

    @Logger.log_method_entry_exit
    def is_products_page_displayed(self) -> bool:
        """Checks if the products page title is visible, indicating successful login."""
        self.logger.info("Checking if products page is displayed.")
        return self._page.locator(self.PRODUCTS_PAGE_TITLE).text_content() == "Products"

    @Logger.log_method_entry_exit
    def login(self, username: str, password: str) -> 'LoginPage':
        """Performs a complete login action."""
        self.logger.info(f"Attempting to log in with username: '{username}'")
        self.enter_username(username)
        self.enter_password(password)
        self.click_login_button()
        return self