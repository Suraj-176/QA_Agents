import allure
import json
from pytest_bdd import scenario, given, when, then, parsers
from playwright.sync_api import APIRequestContext
from helpers.validators.LoginValidator import LoginValidator
from core.logger.Logger import Logger

# Logger instance
logger = Logger().get_logger()

# Store API response for subsequent steps
api_response_context = {}

# Scenarios
@scenario('../features/api/api_login.feature', 'Successful API Login with valid credentials')
def successful_api_login():
    pass

@scenario('../features/api/api_login.feature', 'Data-driven API Login with various credentials')
def data_driven_api_login():
    pass

# Fixtures (can be moved to conftest.py for broader availability)
@given("I have valid API login credentials")
@allure.step("Prepare valid API login credentials")
def valid_api_credentials():
    credentials = {"username": "standard_user", "password": "secret_sauce"} # Example credentials
    logger.info("Prepared valid API login credentials.")
    return credentials

@given(parsers.parse('I have API login credentials: username "{username}" and password "{password}"'))
@allure.step("Prepare API login credentials: username '{username}' and password '{password}'")
def api_credentials_from_feature(username: str, password: str):
    credentials = {"username": username, "password": password}
    logger.info(f"Prepared API login credentials for username '{username}'.")
    return credentials

# When steps
@when("I send a POST request to the login endpoint with these credentials")
@allure.step("Send POST request to login endpoint")
def send_api_login_request(api_request_context: APIRequestContext, valid_api_credentials):
    api_url = "https://api.example.com/login" # Replace with actual API login endpoint
    logger.info(f"Sending POST request to {api_url} with credentials.")
    response = api_request_context.post(api_url, data=valid_api_credentials)
    api_response_context['response'] = response
    logger.info(f"API login request sent. Status: {response.status}")

@when("I send a POST request to the login endpoint with these credentials", target_fixture="api_response")
@allure.step("Send POST request to login endpoint with data-driven credentials")
def send_data_driven_api_login_request(api_request_context: APIRequestContext, api_credentials_from_feature):
    api_url = "https://api.example.com/login" # Replace with actual API login endpoint
    logger.info(f"Sending POST request to {api_url} with data-driven credentials.")
    response = api_request_context.post(api_url, data=api_credentials_from_feature)
    api_response_context['response'] = response
    logger.info(f"Data-driven API login request sent. Status: {response.status}")
    return response # Return response for direct use in next step if needed

# Then steps
@then(parsers.parse("the API response status code should be {status_code:d}"))
@allure.step("Verify API response status code is '{status_code}'")
def verify_api_status_code(status_code: int):
    response = api_response_context.get('response')
    assert response is not None, "API response not found in context."
    is_status_code_valid = LoginValidator.validate_api_status_code(response, status_code)
    assert is_status_code_valid, f"Expected status code {status_code}, but got {response.status}"
    logger.info(f"API response status code {response.status} matches expected {status_code}.")

@then("the API response should contain an authentication token")
@allure.step("Verify API response contains an authentication token")
def verify_api_token_present():
    response = api_response_context.get('response')
    assert response is not None, "API response not found in context."
    response_json = response.json()
    token_present = LoginValidator.validate_api_token_presence(response_json)
    assert token_present, "API response does not contain an authentication token."
    logger.info("API response successfully contains an authentication token.")

@then(parsers.parse("the API response should {token_presence} an authentication token"))
@allure.step("Verify API response '{token_presence}' an authentication token")
def verify_data_driven_api_token_presence(token_presence: str):
    response = api_response_context.get('response')
    assert response is not None, "API response not found in context."
    try:
        response_json = response.json()
    except json.JSONDecodeError:
        response_json = {} # Handle cases where response might not be JSON (e.g., 401 with plain text)

    token_is_present = LoginValidator.validate_api_token_presence(response_json)

    if token_presence == "contain":
        assert token_is_present, "Expected API response to contain an authentication token, but it did not."
        logger.info("Data-driven API scenario: Token found as expected.")
    elif token_presence == "not contain":
        assert not token_is_present, "Expected API response NOT to contain an authentication token, but it did."
        logger.info("Data-driven API scenario: Token not found as expected.")
    else:
        raise ValueError(f"Unknown token presence expectation: {token_presence}")