import allure
from pytest_bdd import scenario, given, when, then, parsers
from playwright.sync_api import Page
from src.pages.loginPage import LoginPage
from helpers.validators.LoginValidator import LoginValidator
from core.logger.Logger import Logger

# Assuming a base_url fixture is available from playwright.config.py or conftest.py
# For simplicity, we'll hardcode it here or assume it's passed via context.
# For data-driven scenarios, you might use a fixture that loads data from CSV/JSON.

# Logger instance
logger = Logger().get_logger()

# Scenarios
@scenario('../features/ui/login.feature', 'Successful UI Login with valid credentials')
def successful_ui_login():
    pass

@scenario('../features/ui/login.feature', 'Data-driven UI Login with various credentials')
def data_driven_ui_login():
    pass

# Fixtures (can be moved to conftest.py for broader availability)
@given("I am on the login page")
@allure.step("Navigate to the login page")
def navigate_to_login_page(page: Page):
    login_page = LoginPage(page)
    login_page.navigate()
    LoginValidator.validate_page_title(page, "Swag Labs") # Example validation
    logger.info("Successfully navigated to the login page.")

# When steps
@when(parsers.parse('I enter username "{username}" and password "{password}"'))
@allure.step("Enter username '{username}' and password '{password}'")
def enter_credentials(page: Page, username: str, password: str):
    login_page = LoginPage(page)
    login_page.enter_username(username).enter_password(password)
    logger.info(f"Entered username '{username}' and masked password.")

@when("I click the login button")
@allure.step("Click the login button")
def click_login_button(page: Page):
    login_page = LoginPage(page)
    login_page.click_login_button()
    logger.info("Clicked the login button.")

# Then steps
@then("I should be logged in successfully")
@allure.step("Verify successful login")
def verify_successful_login(page: Page):
    login_page = LoginPage(page)
    is_successful = LoginValidator.is_ui_login_successful(login_page)
    assert is_successful, "Login was not successful, expected products page."
    logger.info("Successfully verified user is logged in.")

@then("I should see the products page")
@allure.step("Verify products page is displayed")
def verify_products_page(page: Page):
    login_page = LoginPage(page)
    is_products_page = login_page.is_products_page_displayed()
    assert is_products_page, "Products page title 'Products' not found."
    logger.info("Successfully verified products page is displayed.")

@then(parsers.parse('I should "{expected_outcome}"'))
@allure.step("Verify expected outcome: '{expected_outcome}'")
def verify_data_driven_outcome(page: Page, expected_outcome: str):
    login_page = LoginPage(page)
    if expected_outcome == "be logged in successfully":
        is_successful = LoginValidator.is_ui_login_successful(login_page)
        assert is_successful, "Data-driven login failed for successful case."
        logger.info("Data-driven scenario: Successfully logged in.")
    elif expected_outcome == "see an error message":
        error_message = login_page.get_error_message()
        is_error_displayed = LoginValidator.is_ui_error_message_displayed(error_message)
        assert is_error_displayed, "Data-driven login did not show an error message as expected."
        logger.info(f"Data-driven scenario: Error message displayed: '{error_message}'")
    else:
        raise ValueError(f"Unknown expected outcome: {expected_outcome}")