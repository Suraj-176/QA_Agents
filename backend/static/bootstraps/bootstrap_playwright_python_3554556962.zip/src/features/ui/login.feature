Feature: UI Login Functionality

  As a user, I want to be able to log in to the application
  So that I can access protected features.

  @ui @login @smoke
  Scenario: Successful UI Login with valid credentials
    Given I am on the login page
    When I enter username "standard_user" and password "secret_sauce"
    And I click the login button
    Then I should be logged in successfully
    And I should see the products page

  @ui @login @data-driven
  Scenario Outline: Data-driven UI Login with various credentials
    Given I am on the login page
    When I enter username "<username>" and password "<password>"
    And I click the login button
    Then I should "<expected_outcome>"

    Examples: Valid and Invalid Credentials
      | username         | password     | expected_outcome           |
      | standard_user    | secret_sauce | be logged in successfully  |
      | locked_out_user  | secret_sauce | see an error message       |
      | problem_user     | secret_sauce | be logged in successfully  |
      | performance_glitch_user | secret_sauce | be logged in successfully  |
      | invalid_user     | wrong_pass   | see an error message       |
      |                  |              | see an error message       |