Feature: API Login Functionality

  As a system, I want to be able to authenticate via API
  So that I can perform subsequent API operations.

  @api @login @smoke
  Scenario: Successful API Login with valid credentials
    Given I have valid API login credentials
    When I send a POST request to the login endpoint with these credentials
    Then the API response status code should be 200
    And the API response should contain an authentication token

  @api @login @data-driven
  Scenario Outline: Data-driven API Login with various credentials
    Given I have API login credentials: username "<username>" and password "<password>"
    When I send a POST request to the login endpoint with these credentials
    Then the API response status code should be <status_code>
    And the API response should "<token_presence>" an authentication token

    Examples: Valid and Invalid Credentials
      | username         | password     | status_code | token_presence |
      | standard_user    | secret_sauce | 200         | contain        |
      | locked_out_user  | secret_sauce | 401         | not contain    |
      | invalid_user     | wrong_pass   | 401         | not contain    |
      |                  |              | 400         | not contain    |