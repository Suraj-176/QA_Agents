import { Builder, WebDriver } from 'selenium-webdriver';
import * as chrome from 'selenium-webdriver/chrome';
import * as firefox from 'selenium-webdriver/firefox';
import { setDefaultTimeout } from '@cucumber/cucumber'; // For Cucumber specific timeout

/**
 * Interface for global configuration settings.
 */
interface IConfig {
    browser: string;
    headless: boolean;
    baseUrl: string;
    timeout: number;
    maximizeWindow: boolean;
}

/**
 * Global configuration object.
 * Values are loaded from environment variables or default to sensible values.
 */
const config: IConfig = {
    browser: process.env.BROWSER || 'chrome',
    headless: process.env.HEADLESS === 'true',
    baseUrl: process.env.BASE_URL || 'http://localhost:3000', // Example base URL for the application under test
    timeout: parseInt(process.env.DEFAULT_TIMEOUT || '60000', 10), // Default 60 seconds for Cucumber steps
    maximizeWindow: process.env.MAXIMIZE_WINDOW === 'false' ? false : true, // Default to true
};

let driverInstance: WebDriver | null = null;

/**
 * Initializes the WebDriver instance based on the global configuration.
 * This function should be called once globally before all tests begin, typically in a Cucumber `BeforeAll` hook.
 * It ensures a single WebDriver instance is created and configured for the entire test run.
 *
 * @returns {Promise<WebDriver>} A promise that resolves with the initialized WebDriver instance.
 * @throws {Error} If an unsupported browser is specified in the configuration.
 */
export async function setupBrowser(): Promise<WebDriver> {
    if (driverInstance) {
        console.warn('WebDriver instance already exists. Returning existing instance.');
        return driverInstance;
    }

    console.log(`--- Global Setup: Initializing browser: ${config.browser} (headless: ${config.headless}) ---`);

    // Set default timeout for Cucumber steps
    setDefaultTimeout(config.timeout);

    let builder = new Builder().forBrowser(config.browser);

    switch (config.browser.toLowerCase()) {
        case 'chrome':
            const chromeOptions = new chrome.Options();
            if (config.headless) {
                chromeOptions.addArguments('--headless=new');
                chromeOptions.addArguments('--disable-gpu'); // Recommended for headless
            }
            chromeOptions.addArguments('--window-size=1920,1080'); // Consistent viewport size
            chromeOptions.addArguments('--no-sandbox'); // Required for Docker/CI environments
            chromeOptions.addArguments('--disable-dev-shm-usage'); // Recommended for Docker/CI environments
            chromeOptions.addArguments('--disable-extensions');
            chromeOptions.addArguments('--disable-infobars');
            chromeOptions.addArguments('--remote-debugging-port=9222'); // Useful for debugging
            builder.setChromeOptions(chromeOptions);
            break;
        case 'firefox':
            const firefoxOptions = new firefox.Options();
            if (config.headless) {
                firefoxOptions.addArguments('-headless');
            }
            firefoxOptions.addArguments('--window-size=1920,1080'); // Consistent viewport size
            builder.setFirefoxOptions(firefoxOptions);
            break;
        // Add support for other browsers (e.g., Edge, Safari) as needed
        default:
            throw new Error(`Unsupported browser specified in configuration: ${config.browser}`);
    }

    driverInstance = await builder.build();

    // Maximize window only if not running in headless mode and configured to do so
    if (config.maximizeWindow && !config.headless) {
        await driverInstance.manage().window().maximize();
    }

    console.log('--- Global Setup: Browser initialized successfully ---');
    return driverInstance;
}

/**
 * Returns the currently active WebDriver instance.
 * This function should be used by page objects and step definitions to interact with the browser.
 *
 * @returns {WebDriver} The WebDriver instance.
 * @throws {Error} If the WebDriver instance has not been initialized by calling `setupBrowser()` first.
 */
export function getDriver(): WebDriver {
    if (!driverInstance) {
        throw new Error('WebDriver instance has not been initialized. Call setupBrowser() first.');
    }
    return driverInstance;
}

/**
 * Returns the global configuration object.
 * This can be used by tests or other helpers to access configuration values like `baseUrl`.
 *
 * @returns {IConfig} The configuration object.
 */
export function getConfig(): IConfig {
    return config;
}