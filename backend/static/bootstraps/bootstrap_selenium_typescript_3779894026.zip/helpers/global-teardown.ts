import { WebDriver } from 'selenium-webdriver';
import { getDriver } from './global-setup'; // Import getDriver to access the active instance

/**
 * Performs global teardown tasks after all tests have completed.
 * This function should be called once globally after all tests, typically in a Cucumber `AfterAll` hook.
 * Its primary responsibility is to quit the WebDriver instance, releasing browser resources.
 */
export async function teardownBrowser(): Promise<void> {
    console.log('--- Global Teardown Started ---');
    try {
        // Attempt to retrieve the active WebDriver instance.
        // It's wrapped in a try-catch because getDriver() will throw if not initialized,
        // which might happen if setup failed or was skipped.
        const driver: WebDriver = getDriver();
        if (driver) {
            await driver.quit();
            console.log('WebDriver instance quit successfully.');
        }
    } catch (error) {
        // Log the error but do not re-throw, as teardown should ideally complete
        // even if there are issues quitting the driver (e.g., already quit).
        console.error('Error during global teardown (quitting WebDriver):', error);
    } finally {
        // Add any other global cleanup tasks here, such as:
        // - Generating consolidated test reports (e.g., Allure, Extent)
        // - Cleaning up temporary files or test data
        console.log('--- Global Teardown Finished ---');
    }
}