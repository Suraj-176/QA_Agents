import { LoginPage } from '../../src/pages/loginPage';

/**
 * LoginValidator class implements the Zero Assertions policy for BDD step definitions.
 * This class encapsulates validation logic and returns boolean or specific values,
 * allowing step definitions to perform a single, high-level assertion on the returned value.
 */
export class LoginValidator {

    /**
     * Validates if the user is successfully logged in.
     * @param {LoginPage} loginPage - The LoginPage instance.
     * @returns {Promise<boolean>} - True if logged in, false otherwise.
     */
    public async validateSuccessfulLogin(loginPage: LoginPage): Promise<boolean> {
        return loginPage.isLoggedIn();
    }

    /**
     * Retrieves the error message text from the login page.
     * @param {LoginPage} loginPage - The LoginPage instance.
     * @returns {Promise<string>} - The actual error message text.
     */
    public async getLoginErrorMessage(loginPage: LoginPage): Promise<string> {
        return loginPage.getErrorMessageText();
    }

    /**
     * Validates if the current page is the login page.
     * @param {LoginPage} loginPage - The LoginPage instance.
     * @param {string} expectedLoginPageUrl - The expected URL of the login page.
     * @returns {Promise<boolean>} - True if on login page, false otherwise.
     */
    public async validateOnLoginPage(loginPage: LoginPage, expectedLoginPageUrl: string): Promise<boolean> {
        return loginPage.isOnLoginPage(expectedLoginPageUrl);
    }

    /**
     * Retrieves the status code from an API response.
     * @param {any} apiResponse - The API response object (e.g., from a fetch call).
     * @returns {number} - The HTTP status code.
     */
    public getApiResponseStatusCode(apiResponse: any): number {
        return apiResponse?.status;
    }

    /**
     * Validates if an API response contains an authentication token.
     * @param {any} apiResponse - The API response object.
     * @returns {boolean} - True if a token is present, false otherwise.
     */
    public validateApiResponseHasToken(apiResponse: any): boolean {
        return !!apiResponse?.data?.token;
    }

    /**
     * Retrieves the error message from an API response.
     * @param {any} apiResponse - The API response object.
     * @returns {string} - The error message string, or an empty string if not found.
     */
    public getApiErrorMessage(apiResponse: any): string {
        return apiResponse?.data?.message || '';
    }
}