package com.qa.core.base;

import com.qa.core.driver.DriverManager;
import com.qa.core.logger.LoggerUtil;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.File;
import java.io.IOException;
import java.time.Duration;

/**
 * BasePage class provides common WebDriver interactions and utilities for Page Object Models.
 * It encapsulates explicit waits, error handling, and screenshot capabilities to build robust and
 * less flaky tests. All page objects should extend this class.
 */
public class BasePage {

    protected WebDriver driver;
    protected WebDriverWait wait;
    private static final int DEFAULT_WAIT_SECONDS = 15; // Default explicit wait timeout
    private static final int MAX_RETRIES = 3; // Max retries for click operations

    /**
     * Constructor for BasePage.
     * Initializes the WebDriver and WebDriverWait with a default timeout.
     *
     * @param driver The WebDriver instance to be used by the page object.
     */
    public BasePage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(DEFAULT_WAIT_SECONDS));
    }

    /**
     * Waits for an element to be visible on the page using explicit wait.
     *
     * @param locator The By locator of the element.
     * @return The WebElement once it is visible.
     * @throws TimeoutException If the element is not visible within the default timeout.
     */
    protected WebElement waitVisible(By locator) {
        try {
            LoggerUtil.info("Waiting for visibility of element: " + locator.toString());
            return wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
        } catch (TimeoutException e) {
            LoggerUtil.error("Timeout waiting for element visibility: " + locator.toString() + ". Error: " + e.getMessage());
            captureScreenshot("ElementVisibilityTimeout_" + locator.toString().replaceAll("[^a-zA-Z0-9]", "_"));
            throw e;
        } catch (WebDriverException e) {
            LoggerUtil.error("WebDriver exception while waiting for element visibility: " + locator.toString() + ". Error: " + e.getMessage());
            captureScreenshot("ElementVisibilityWebDriverError_" + locator.toString().replaceAll("[^a-zA-Z0-9]", "_"));
            throw e;
        }
    }

    /**
     * Clicks on an element after waiting for its visibility.
     * Includes retry mechanism for StaleElementReferenceException.
     *
     * @param locator The By locator of the element to click.
     */
    protected void click(By locator) {
        for (int i = 0; i < MAX_RETRIES; i++) {
            try {
                WebElement element = waitVisible(locator);
                LoggerUtil.info("Attempting to click element: " + locator.toString() + " (Attempt " + (i + 1) + ")");
                element.click();
                return; // Click successful, exit loop
            } catch (StaleElementReferenceException e) {
                LoggerUtil.warn("StaleElementReferenceException encountered for " + locator.toString() + ". Retrying... (Attempt " + (i + 1) + ")");
                if (i == MAX_RETRIES - 1) {
                    LoggerUtil.error("Failed to click element after " + MAX_RETRIES + " retries due to StaleElementReferenceException: " + locator.toString() + ". Error: " + e.getMessage());
                    captureScreenshot("ClickStaleElementError_" + locator.toString().replaceAll("[^a-zA-Z0-9]", "_"));
                    throw e;
                }
            } catch (ElementClickInterceptedException e) {
                LoggerUtil.warn("ElementClickInterceptedException encountered for " + locator.toString() + ". Attempting JavaScript click. (Attempt " + (i + 1) + ")");
                try {
                    WebElement element = waitVisible(locator); // Re-find element
                    ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
                    return; // Click successful via JS, exit loop
                } catch (WebDriverException jsEx) {
                    LoggerUtil.error("Failed to click element via JavaScript after interception: " + locator.toString() + ". Error: " + jsEx.getMessage());
                    captureScreenshot("ClickInterceptedJSError_" + locator.toString().replaceAll("[^a-zA-Z0-9]", "_"));
                    throw jsEx;
                }
            } catch (WebDriverException e) {
                LoggerUtil.error("WebDriver exception while clicking element: " + locator.toString() + ". Error: " + e.getMessage());
                captureScreenshot("ClickWebDriverError_" + locator.toString().replaceAll("[^a-zA-Z0-9]", "_"));
                throw e;
            }
        }
    }

    /**
     * Sends keys to an element after waiting for its visibility.
     * Clears the field before sending keys.
     *
     * @param locator The By locator of the input field.
     * @param text    The text to send.
     */
    protected void sendKeys(By locator, String text) {
        try {
            WebElement element = waitVisible(locator);
            LoggerUtil.info("Sending keys to element: " + locator.toString() + " with text: " + LoggerUtil.maskSensitiveData(text));
            element.clear();
            element.sendKeys(text);
        } catch (WebDriverException e) {
            LoggerUtil.error("WebDriver exception while sending keys to element: " + locator.toString() + ". Error: " + e.getMessage());
            captureScreenshot("SendKeysWebDriverError_" + locator.toString().replaceAll("[^a-zA-Z0-9]", "_"));
            throw e;
        }
    }

    /**
     * Scrolls the page to bring the specified element into view using JavaScript.
     *
     * @param locator The By locator of the element to scroll to.
     */
    protected void javascriptScroll(By locator) {
        try {
            WebElement element = waitVisible(locator);
            LoggerUtil.info("Scrolling to element: " + locator.toString());
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
        } catch (WebDriverException e) {
            LoggerUtil.error("WebDriver exception while scrolling to element: " + locator.toString() + ". Error: " + e.getMessage());
            captureScreenshot("ScrollWebDriverError_" + locator.toString().replaceAll("[^a-zA-Z0-9]", "_"));
            throw e;
        }
    }

    /**
     * Captures a full-page viewport screenshot and saves it to the 'screenshots' directory.
     * The filename includes a timestamp for uniqueness.
     *
     * @param screenshotName A descriptive name for the screenshot.
     * @return The absolute path to the saved screenshot file, or null if an error occurred.
     */
    public String captureScreenshot(String screenshotName) {
        if (driver == null) {
            LoggerUtil.error("Driver is null, cannot capture screenshot.");
            return null;
        }

        try {
            File srcFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
            String timestamp = String.valueOf(System.currentTimeMillis());
            String fileName = screenshotName + "_" + timestamp + ".png";
            String screenshotPath = System.getProperty("user.dir") + File.separator + "screenshots" + File.separator + fileName;
            FileUtils.copyFile(srcFile, new File(screenshotPath));
            LoggerUtil.info("Screenshot captured: " + screenshotPath);
            return screenshotPath;
        } catch (IOException e) {
            LoggerUtil.error("Failed to capture screenshot: " + screenshotName + ". Error: " + e.getMessage());
            return null;
        } catch (WebDriverException e) {
            LoggerUtil.error("WebDriver exception during screenshot capture: " + screenshotName + ". Error: " + e.getMessage());
            return null;
        }
    }

    /**
     * Retrieves the text of an element after waiting for its visibility.
     *
     * @param locator The By locator of the element.
     * @return The text content of the element.
     */
    protected String getText(By locator) {
        try {
            WebElement element = waitVisible(locator);
            String text = element.getText();
            LoggerUtil.info("Retrieved text from element: " + locator.toString() + " - " + text);
            return text;
        } catch (WebDriverException e) {
            LoggerUtil.error("WebDriver exception while getting text from element: " + locator.toString() + ". Error: " + e.getMessage());
            captureScreenshot("GetTextWebDriverError_" + locator.toString().replaceAll("[^a-zA-Z0-9]", "_"));
            throw e;
        }
    }

    /**
     * Checks if an element is displayed on the page after waiting for its visibility.
     *
     * @param locator The By locator of the element.
     * @return true if the element is displayed, false otherwise.
     */
    protected boolean isDisplayed(By locator) {
        try {
            WebElement element = waitVisible(locator);
            boolean displayed = element.isDisplayed();
            LoggerUtil.info("Element " + locator.toString() + " is displayed: " + displayed);
            return displayed;
        } catch (TimeoutException e) {
            LoggerUtil.info("Element " + locator.toString() + " is not displayed (Timeout).");
            return false;
        } catch (WebDriverException e) {
            LoggerUtil.error("WebDriver exception while checking if element is displayed: " + locator.toString() + ". Error: " + e.getMessage());
            captureScreenshot("IsDisplayedWebDriverError_" + locator.toString().replaceAll("[^a-zA-Z0-9]", "_"));
            throw e;
        }
    }
}