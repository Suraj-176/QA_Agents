import { WebDriver, By, WebElement } from 'selenium-webdriver';
// Assuming BasePage.ts exists and provides common driver interactions
// For demonstration, a minimal BasePage structure is assumed.
// In a real project, you would import it like:
// import { BasePage } from '../core/base/BasePage';

// Minimal BasePage for demonstration purposes if not previously generated in TS
class BasePage {
    protected driver: WebDriver;

    constructor(driver: WebDriver) {
        this.driver = driver;
    }

    protected async findElement(locator: By): Promise<WebElement> {
        // In a real scenario, add explicit waits here
        return this.driver.findElement(locator);
    }

    protected async type(locator: By, text: string): Promise<void> {
        const element = await this.findElement(locator);
        await element.clear(); // Clear existing text before typing
        await element.sendKeys(text);
    }

    protected async click(locator: By): Promise<void> {
        await (await this.findElement(locator)).click();
    }

    protected async getText(locator: By): Promise<string> {
        return (await this.findElement(locator)).getText();
    }

    protected async isDisplayed(locator: By): Promise<boolean> {
        try {
            return await (await this.findElement(locator)).isDisplayed();
        } catch (error) {
            return false; // Element not found or not displayed
        }
    }

    protected async getCurrentUrl(): Promise<string> {
        return this.driver.getCurrentUrl();
    }
}

export class LoginPage extends BasePage {
    // Locators
    private usernameInput: By = By.id('username');
    private passwordInput: By = By.id('password');
    private loginButton: By = By.id('loginButton');
    private errorMessage: By = By.css('.error-message');
    private dashboardHeader: By = By.css('h1.dashboard-header'); // Assuming this indicates successful login

    constructor(driver: WebDriver) {
        super(driver);
    }

    /**
     * Navigates to the login page URL.
     * @returns {LoginPage} - The current LoginPage instance for fluent chaining.
     */
    public async navigateToLoginPage(url: string): Promise<LoginPage> {
        await this.driver.get(url);
        return this;
    }

    /**
     * Enters the username into the username input field.
     * @param {string} username - The username to enter.
     * @returns {LoginPage} - The current LoginPage instance for fluent chaining.
     */
    public async enterUsername(username: string): Promise<LoginPage> {
        await this.type(this.usernameInput, username);
        return this;
    }

    /**
     * Enters the password into the password input field.
     * @param {string} password - The password to enter.
     * @returns {LoginPage} - The current LoginPage instance for fluent chaining.
     */
    public async enterPassword(password: string): Promise<LoginPage> {
        await this.type(this.passwordInput, password);
        return this;
    }

    /**
     * Clicks the login button.
     * @returns {LoginPage} - The current LoginPage instance for fluent chaining.
     */
    public async clickLoginButton(): Promise<LoginPage> {
        await this.click(this.loginButton);
        return this;
    }

    /**
     * Retrieves the text of the error message displayed on the page.
     * @returns {Promise<string>} - The error message text, or an empty string if not found.
     */
    public async getErrorMessageText(): Promise<string> {
        if (await this.isDisplayed(this.errorMessage)) {
            return this.getText(this.errorMessage);
        }
        return '';
    }

    /**
     * Checks if the user is successfully logged in by verifying the presence of a dashboard element.
     * @returns {Promise<boolean>} - True if logged in, false otherwise.
     */
    public async isLoggedIn(): Promise<boolean> {
        return this.isDisplayed(this.dashboardHeader);
    }

    /**
     * Checks if the current URL is still the login page URL.
     * @param {string} loginPageUrl - The expected URL of the login page.
     * @returns {Promise<boolean>} - True if on login page, false otherwise.
     */
    public async isOnLoginPage(loginPageUrl: string): Promise<boolean> {
        const currentUrl = await this.getCurrentUrl();
        return currentUrl.includes(loginPageUrl);
    }
}