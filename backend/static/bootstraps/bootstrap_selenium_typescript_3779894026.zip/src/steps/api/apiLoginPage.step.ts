import { Given, When, Then, World } from '@cucumber/cucumber';
import { LoginValidator } from '../../../helpers/validators/LoginValidator';
import * as allure from 'allure-cucumberjs';
import { expect } from 'chai'; // Using chai for assertions

// Mock API client for demonstration
class ApiClient {
    private baseUrl: string;

    constructor(baseUrl: string) {
        this.baseUrl = baseUrl;
    }

    public async post(endpoint: string, data: any): Promise<any> {
        // Simulate API call
        return new Promise(resolve => {
            setTimeout(() => {
                if (endpoint === '/api/login') {
                    if (data.username === 'apiuser' && data.password === 'apipass') {
                        resolve({ status: 200, data: { token: 'mock_auth_token_123', message: 'Login successful' } });
                    } else {
                        resolve({ status: 401, data: { message: 'Authentication failed' } });
                    }
                } else {
                    resolve({ status: 404, data: { message: 'Not Found' } });
                }
            }, 100); // Simulate network delay
        });
    }
}

// Extend Cucumber World to include API client and validator
interface CustomWorld extends World {
    apiClient: ApiClient;
    loginValidator: LoginValidator;
    apiResponse: any;
    apiUrl: string; // Assuming apiUrl is configured
}

Given('I have valid API credentials', async function (this: CustomWorld) {
    await allure.step('Setup valid API credentials', async () => {
        this.apiClient = new ApiClient(this.apiUrl);
        this.loginValidator = new LoginValidator();
        // No specific action needed here, just setup
    });
});

Given('I have invalid API credentials', async function (this: CustomWorld) {
    await allure.step('Setup invalid API credentials', async () => {
        this.apiClient = new ApiClient(this.apiUrl);
        this.loginValidator = new LoginValidator();
        // No specific action needed here, just setup
    });
});

When('I send a POST request to the login API endpoint with username {string} and password {string}', async function (this: CustomWorld, username: string, password: string) {
    await allure.step(`Send API login request for user: ${username}`, async () => {
        this.apiResponse = await this.apiClient.post('/api/login', { username, password });
    });
});

Then('the API response status code should be {int}', async function (this: CustomWorld, expectedStatusCode: number) {
    await allure.step(`Verify API response status code: ${expectedStatusCode}`, async () => {
        const actualStatusCode = this.loginValidator.getApiResponseStatusCode(this.apiResponse);
        expect(actualStatusCode).to.equal(expectedStatusCode);
    });
});

Then('the API response should contain an authentication token', async function (this: CustomWorld) {
    await allure.step('Verify API response contains auth token', async () => {
        const hasToken = this.loginValidator.validateApiResponseHasToken(this.apiResponse);
        expect(hasToken).to.be.true;
    });
});

Then('the API response should contain an error message {string}', async function (this: CustomWorld, expectedErrorMessage: string) {
    await allure.step(`Verify API response error message: "${expectedErrorMessage}"`, async () => {
        const actualErrorMessage = this.loginValidator.getApiErrorMessage(this.apiResponse);
        expect(actualErrorMessage).to.equal(expectedErrorMessage);
    });
});