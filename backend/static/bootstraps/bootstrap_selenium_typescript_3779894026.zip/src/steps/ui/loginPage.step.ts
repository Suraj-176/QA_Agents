import { Given, When, Then, World } from '@cucumber/cucumber';
import { WebDriver } from 'selenium-webdriver';
import { LoginPage } from '../../pages/loginPage';
import { LoginValidator } from '../../../helpers/validators/LoginValidator';
import * as allure from 'allure-cucumberjs';
import { expect } from 'chai'; // Using chai for assertions

// Extend Cucumber World to include WebDriver and page objects
interface CustomWorld extends World {
    driver: WebDriver;
    loginPage: LoginPage;
    loginValidator: LoginValidator;
    appUrl: string; // Assuming appUrl is configured in global-setup or cucumber.js
}

Given('I am on the login page', async function (this: CustomWorld) {
    await allure.step('Navigate to login page', async () => {
        this.loginPage = new LoginPage(this.driver);
        this.loginValidator = new LoginValidator();
        await this.loginPage.navigateToLoginPage(this.appUrl + '/login'); // Assuming /login is the path
    });
});

When('I enter username {string}', async function (this: CustomWorld, username: string) {
    await allure.step(`Enter username: ${username}`, async () => {
        await this.loginPage.enterUsername(username);
    });
});

When('I enter password {string}', async function (this: CustomWorld, password: string) {
    await allure.step(`Enter password: ${password}`, async () => {
        await this.loginPage.enterPassword(password);
    });
});

When('I click the login button', async function (this: CustomWorld) {
    await allure.step('Click login button', async () => {
        await this.loginPage.clickLoginButton();
    });
});

Then('I should be logged in successfully', async function (this: CustomWorld) {
    await allure.step('Verify successful login', async () => {
        const isLoggedIn = await this.loginValidator.validateSuccessfulLogin(this.loginPage);
        expect(isLoggedIn).to.be.true;
    });
});

Then('I should see the dashboard page', async function (this: CustomWorld) {
    await allure.step('Verify dashboard page is displayed', async () => {
        // Assuming the dashboard URL is different or a specific element is present
        const isLoggedIn = await this.loginValidator.validateSuccessfulLogin(this.loginPage); // Re-use check for dashboard element
        expect(isLoggedIn).to.be.true;
    });
});

Then('I should see an error message {string}', async function (this: CustomWorld, expectedErrorMessage: string) {
    await allure.step(`Verify error message: "${expectedErrorMessage}"`, async () => {
        const actualErrorMessage = await this.loginValidator.getLoginErrorMessage(this.loginPage);
        expect(actualErrorMessage).to.equal(expectedErrorMessage);
    });
});

Then('I should remain on the login page', async function (this: CustomWorld) {
    await allure.step('Verify still on login page', async () => {
        const isOnLoginPage = await this.loginValidator.validateOnLoginPage(this.loginPage, this.appUrl + '/login');
        expect(isOnLoginPage).to.be.true;
    });
});