@api @login @smoke
Feature: API Login Functionality

  As an API consumer, I want to be able to authenticate via API
  So that I can access protected API resources.

  Scenario: Successful API login with valid credentials
    Given I have valid API credentials
    When I send a POST request to the login API endpoint with username "apiuser" and password "apipass"
    Then the API response status code should be 200
    And the API response should contain an authentication token

  Scenario: API login with invalid credentials
    Given I have invalid API credentials
    When I send a POST request to the login API endpoint with username "invalidapiuser" and password "wrongapipass"
    Then the API response status code should be 401
    And the API response should contain an error message "Authentication failed"