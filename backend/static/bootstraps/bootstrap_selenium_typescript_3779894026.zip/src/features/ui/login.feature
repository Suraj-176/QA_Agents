@ui @login @smoke
Feature: UI Login Functionality

  As a user, I want to be able to log in to the application
  So that I can access protected features.

  Scenario: Successful login with valid credentials
    Given I am on the login page
    When I enter username "testuser"
    And I enter password "password123"
    And I click the login button
    Then I should be logged in successfully
    And I should see the dashboard page

  Scenario: Login with invalid credentials
    Given I am on the login page
    When I enter username "invaliduser"
    And I enter password "wrongpass"
    And I click the login button
    Then I should see an error message "Invalid credentials"
    And I should remain on the login page