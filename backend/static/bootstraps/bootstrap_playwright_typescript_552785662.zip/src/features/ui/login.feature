Feature: UI Login Functionality

  As a user
  I want to be able to log in to the application
  So that I can access my account

  @ui @login @smoke
  Scenario: Successful login with valid credentials
    Given I am on the login page
    When I enter username "testuser" and password "password123"
    And I click the login button
    Then I should be logged in successfully

  @ui @login @negative
  Scenario: Unsuccessful login with invalid credentials
    Given I am on the login page
    When I enter username "invaliduser" and password "wrongpassword"
    And I click the login button
    Then I should see an error message "Invalid credentials"

  @ui @login @negative
  Scenario: Unsuccessful login with empty credentials
    Given I am on the login page
    When I enter username "" and password ""
    And I click the login button
    Then I should see an error message "Username and password are required"