Feature: API Login Functionality

  As an automation framework
  I want to be able to log in via API
  So that I can perform backend operations or get authentication tokens

  @api @login @smoke
  Scenario: Successful API login with valid credentials
    When I send a POST request to the login API with username "apiuser" and password "apipassword"
    Then the API response status should be 200
    And the API response should contain a valid authentication token

  @api @login @negative
  Scenario: Unsuccessful API login with invalid credentials
    When I send a POST request to the login API with username "invalidapiuser" and password "wrongapipassword"
    Then the API response status should be 401
    And the API response should contain an error message "Invalid credentials"