import { Page, Locator } from '@playwright/test';
import { BasePage } from './basePage'; // Assuming BasePage exists in src/pages/basePage.ts

/**
 * Represents the Login Page of the application.
 * Extends BasePage to inherit common page functionalities.
 * Uses fluent returns for method chaining.
 */
export class LoginPage extends BasePage {
  // Locators
  private readonly usernameInput: Locator;
  private readonly passwordInput: Locator;
  private readonly loginButton: Locator;
  private readonly errorMessage: Locator;
  private readonly successMessage: Locator; // Assuming a success message or dashboard element

  constructor(page: Page) {
    super(page);
    this.usernameInput = page.locator('#username');
    this.passwordInput = page.locator('#password');
    this.loginButton = page.locator('#loginButton');
    this.errorMessage = page.locator('.error-message');
    this.successMessage = page.locator('#dashboardHeader'); // Example: an element on the dashboard after successful login
  }

  /**
   * Navigates to the login page.
   * @returns {this} The current LoginPage instance for chaining.
   */
  public async navigateToLoginPage(): Promise<this> {
    // Assuming Config.BASE_URL is available globally or imported
    // For this example, let's hardcode or assume a base path
    await this.page.goto('/login');
    return this;
  }

  /**
   * Fills the username input field.
   * @param {string} username - The username to enter.
   * @returns {this} The current LoginPage instance for chaining.
   */
  public async fillUsername(username: string): Promise<this> {
    await this.usernameInput.fill(username);
    return this;
  }

  /**
   * Fills the password input field.
   * @param {string} password - The password to enter.
   * @returns {this} The current LoginPage instance for chaining.
   */
  public async fillPassword(password: string): Promise<this> {
    await this.passwordInput.fill(password);
    return this;
  }

  /**
   * Clicks the login button.
   * @returns {this} The current LoginPage instance for chaining.
   */
  public async clickLoginButton(): Promise<this> {
    await this.loginButton.click();
    return this;
  }

  /**
   * Performs a full login operation.
   * @param {string} username - The username.
   * @param {string} password - The password.
   * @returns {this} The current LoginPage instance for chaining.
   */
  public async login(username: string, password: string): Promise<this> {
    await this.fillUsername(username);
    await this.fillPassword(password);
    await this.clickLoginButton();
    return this;
  }

  /**
   * Checks if an error message is visible.
   * @returns {Promise<boolean>} True if the error message is visible, false otherwise.
   */
  public async isErrorMessageVisible(): Promise<boolean> {
    return await this.errorMessage.isVisible();
  }

  /**
   * Gets the text of the error message.
   * @returns {Promise<string | null>} The error message text, or null if not visible.
   */
  public async getErrorMessageText(): Promise<string | null> {
    return (await this.isErrorMessageVisible()) ? await this.errorMessage.textContent() : null;
  }

  /**
   * Checks if the user is successfully logged in (e.g., by checking for a dashboard element).
   * @returns {Promise<boolean>} True if logged in, false otherwise.
   */
  public async isUserLoggedIn(): Promise<boolean> {
    return await this.successMessage.isVisible();
  }
}