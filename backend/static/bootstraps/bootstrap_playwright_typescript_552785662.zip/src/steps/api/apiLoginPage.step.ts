import { When, Then, setDefaultTimeout } from '@cucumber/cucumber';
import { expect } from '@playwright/test';
import * as allure from 'allure-js-commons';
import { APIClient } from '../../core/api/APIClient'; // Assuming APIClient exists
import { Config } from '../../core/config/Config'; // Assuming Config exists
import { LoginValidator } from '../../helpers/validators/LoginValidator';
import { CustomWorld } from '../../helpers/custom-world'; // Assuming CustomWorld provides 'apiClient'

setDefaultTimeout(60 * 1000); // Set default timeout for steps to 60 seconds

let apiClient: APIClient;
let loginValidator: LoginValidator;
let apiResponse: any; // To store the API response for subsequent steps

When('I send a POST request to the login API with username {string} and password {string}', async function (this: CustomWorld, username: string, password: string) {
  await allure.step(`Send API login request for username: '${username}'`, async () => {
    apiClient = this.apiClient || new APIClient(Config.get('apiBaseUrl')); // Initialize if not already in CustomWorld
    loginValidator = new LoginValidator();

    const loginEndpoint = '/api/login'; // Example API endpoint
    const requestBody = { username, password };

    apiResponse = await apiClient.post(loginEndpoint, requestBody);
    this.apiResponse = apiResponse; // Store in CustomWorld for other steps if needed
  });
});

Then('the API response status should be {int}', async function (this: CustomWorld, expectedStatus: number) {
  await allure.step(`Verify API response status: ${expectedStatus}`, async () => {
    // Using the validator to check the status, then asserting the validator's result
    expect(loginValidator.validateApiResponseStatus(this.apiResponse, expectedStatus)).toBe(true, `API response status should be ${expectedStatus}`);
  });
});

Then('the API response should contain a valid authentication token', async function (this: CustomWorld) {
  await allure.step('Verify API response contains authentication token', async () => {
    // Using the validator to check for the token, then asserting the validator's result
    expect(loginValidator.validateApiAuthToken(this.apiResponse)).toBe(true, 'API response should contain a valid authentication token');
  });
});

Then('the API response should contain an error message {string}', async function (this: CustomWorld, expectedErrorMessage: string) {
  await allure.step(`Verify API response error message: '${expectedErrorMessage}'`, async () => {
    // Using the validator to check for the error message, then asserting the validator's result
    expect(loginValidator.validateApiErrorMessage(this.apiResponse, expectedErrorMessage)).toBe(true, `API response should contain error message '${expectedErrorMessage}'`);
  });
});