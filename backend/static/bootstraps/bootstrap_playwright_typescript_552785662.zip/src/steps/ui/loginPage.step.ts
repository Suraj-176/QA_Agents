import { Given, When, Then, setDefaultTimeout } from '@cucumber/cucumber';
import { expect } from '@playwright/test';
import * as allure from 'allure-js-commons';
import { LoginPage } from '../../pages/loginPage';
import { LoginValidator } from '../../helpers/validators/LoginValidator';
import { CustomWorld } from '../../helpers/custom-world'; // Assuming CustomWorld provides 'page'

setDefaultTimeout(60 * 1000); // Set default timeout for steps to 60 seconds

let loginPage: LoginPage;
let loginValidator: LoginValidator;

Given('I am on the login page', async function (this: CustomWorld) {
  await allure.step('Navigate to login page', async () => {
    loginPage = new LoginPage(this.page);
    loginValidator = new LoginValidator();
    await loginPage.navigateToLoginPage();
    await expect(this.page).toHaveURL(/.*login/); // Verify URL contains /login
  });
});

When('I enter username {string} and password {string}', async function (this: CustomWorld, username: string, password: string) {
  await allure.step(`Enter credentials: username='${username}', password='${'*'.repeat(password.length)}'`, async () => {
    await loginPage.fillUsername(username);
    await loginPage.fillPassword(password);
  });
});

When('I click the login button', async function (this: CustomWorld) {
  await allure.step('Click login button', async () => {
    await loginPage.clickLoginButton();
  });
});

Then('I should be logged in successfully', async function (this: CustomWorld) {
  await allure.step('Verify successful login', async () => {
    // Using the validator to check the state, then asserting the validator's result
    expect(await loginValidator.isUILoginSuccessful(loginPage)).toBe(true, 'User should be logged in successfully');
  });
});

Then('I should see an error message {string}', async function (this: CustomWorld, expectedErrorMessage: string) {
  await allure.step(`Verify error message: '${expectedErrorMessage}'`, async () => {
    // Using the validator to check the error message, then asserting the validator's result
    expect(await loginValidator.isUILoginFailed(loginPage, expectedErrorMessage)).toBe(true, `Error message '${expectedErrorMessage}' should be visible`);
  });
});