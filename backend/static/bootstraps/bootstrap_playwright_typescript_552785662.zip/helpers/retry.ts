import { Logger } from '@core/logger/Logger'; // Assuming Logger.ts is in core/logger

/**
 * Retries an asynchronous function a specified number of times with an optional delay.
 * This helper is useful for handling flaky operations, transient network issues,
 * or waiting for eventual consistency in the system under test.
 *
 * @template T The return type of the asynchronous function.
 * @param fn The asynchronous function to retry. It should return a Promise.
 * @param maxRetries The maximum number of times to retry the function (0 means one initial attempt + 0 retries).
 * @param delayMs The delay in milliseconds between retries (default: 1000ms).
 * @returns A Promise that resolves with the result of the function if successful.
 * @throws The last error encountered if all retries fail.
 */
export async function retry<T>(
  fn: () => Promise<T>,
  maxRetries: number,
  delayMs: number = 1000
): Promise<T> {
  let lastError: Error | undefined;

  for (let i = 0; i <= maxRetries; i++) {
    try {
      return await fn();
    } catch (error: any) {
      lastError = error;
      const attemptNumber = i + 1;
      const totalAttempts = maxRetries + 1;

      if (i < maxRetries) {
        Logger.warn(`Attempt ${attemptNumber}/${totalAttempts} failed. Retrying in ${delayMs}ms... Error: ${error.message}`);
        await new Promise(resolve => setTimeout(resolve, delayMs));
      } else {
        Logger.error(`All ${totalAttempts} attempts failed for operation. Last error: ${error.message}`);
      }
    }
  }
  // If we reach here, all retries have failed. Throw the last error.
  throw lastError;
}