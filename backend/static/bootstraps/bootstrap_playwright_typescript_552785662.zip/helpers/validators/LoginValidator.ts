import { Page, APIResponse } from '@playwright/test';
import { LoginPage } from '../../src/pages/loginPage'; // Import LoginPage for UI validations

/**
 * Validator class for login-related assertions, adhering to the Zero Assertions policy.
 * Methods return boolean or throw errors, allowing step definitions to use `expect` on the results.
 */
export class LoginValidator {

  /**
   * Validates if the UI login was successful.
   * @param {LoginPage} loginPage - The LoginPage instance.
   * @returns {Promise<boolean>} True if login was successful, false otherwise.
   */
  public async isUILoginSuccessful(loginPage: LoginPage): Promise<boolean> {
    // Check if the success indicator (e.g., dashboard header) is visible
    return await loginPage.isUserLoggedIn();
  }

  /**
   * Validates if the UI login failed with a specific error message.
   * @param {LoginPage} loginPage - The LoginPage instance.
   * @param {string} expectedErrorMessage - The expected error message text.
   * @returns {Promise<boolean>} True if the error message is visible and matches, false otherwise.
   */
  public async isUILoginFailed(loginPage: LoginPage, expectedErrorMessage: string): Promise<boolean> {
    const isErrorVisible = await loginPage.isErrorMessageVisible();
    if (!isErrorVisible) {
      return false;
    }
    const actualErrorMessage = await loginPage.getErrorMessageText();
    return actualErrorMessage === expectedErrorMessage;
  }

  /**
   * Validates the status code of an API response.
   * @param {APIResponse} response - The Playwright APIResponse object.
   * @param {number} expectedStatus - The expected HTTP status code.
   * @returns {boolean} True if the status matches, false otherwise.
   */
  public validateApiResponseStatus(response: APIResponse, expectedStatus: number): boolean {
    return response.status() === expectedStatus;
  }

  /**
   * Validates if an API response contains a specific authentication token.
   * Assumes the token is in the response body (e.g., `response.json().token`).
   * @param {APIResponse} response - The Playwright APIResponse object.
   * @returns {Promise<boolean>} True if a token is found and appears valid, false otherwise.
   */
  public async validateApiAuthToken(response: APIResponse): Promise<boolean> {
    try {
      const json = await response.json();
      // Example: Check if 'token' property exists and is a non-empty string
      return typeof json.token === 'string' && json.token.length > 0;
    } catch (error) {
      // If response is not JSON or token is not found
      return false;
    }
  }

  /**
   * Validates if an API response contains a specific error message in its body.
   * Assumes the error message is in `response.json().message` or similar.
   * @param {APIResponse} response - The Playwright APIResponse object.
   * @param {string} expectedErrorMessage - The expected error message text.
   * @returns {Promise<boolean>} True if the error message is found and matches, false otherwise.
   */
  public async validateApiErrorMessage(response: APIResponse, expectedErrorMessage: string): Promise<boolean> {
    try {
      const json = await response.json();
      // Example: Check if 'message' property exists and matches
      return json.message === expectedErrorMessage;
    } catch (error) {
      // If response is not JSON or message is not found
      return false;
    }
  }
}