import { FullConfig } from '@playwright/test';
import { Config } from '@core/config/Config'; // Assuming Config.ts is in core/config
import { Logger } from '@core/logger/Logger'; // Assuming Logger.ts is in core/logger
import * as dotenv from 'dotenv'; // Required for loading .env files
import path from 'path';

/**
 * Global setup function for Playwright.
 * This function runs once before all tests.
 * It's responsible for initializing global configurations, environment variables,
 * and any other one-time setup required for the test suite.
 *
 * @param config The Playwright FullConfig object.
 */
async function globalSetup(config: FullConfig) {
  Logger.info('--- Global Setup Started ---');

  // 1. Load environment variables from .env file
  // This allows managing different configurations (e.g., .env.dev, .env.prod)
  // Make sure 'dotenv' package is installed (npm install dotenv)
  const envPath = path.resolve(__dirname, '../../.env'); // Assumes .env is at the project root
  dotenv.config({ path: envPath });
  Logger.info(`Environment variables loaded from: ${envPath}`);

  // 2. Initialize the global configuration manager
  // This assumes Config.ts has a static method or a singleton pattern to load/initialize config
  try {
    Config.initialize(); // Load configuration based on environment variables
    Logger.info(`Configuration initialized for environment: ${Config.get('env') || 'default'}`);
    Logger.info(`Base URL: ${Config.get('baseURL')}`);
    // You might want to log other non-sensitive config details here
  } catch (error: any) {
    Logger.error(`Failed to initialize configuration: ${error.message}`);
    process.exit(1); // Exit if configuration fails, as tests cannot proceed
  }

  // 3. Perform any necessary global API authentication or setup
  // Example: Authenticate with an API and store the token for subsequent tests
  // This would typically use the APIClient from Phase 1
  /*
  try {
    const apiClient = new APIClient(Config.get('baseURL')); // Assuming APIClient takes baseURL
    const username = Config.get('apiUser');
    const password = Config.get('apiPassword');
    if (username && password) {
      Logger.info('Attempting API authentication...');
      const authToken = await apiClient.authenticate(username, password);
      process.env.AUTH_TOKEN = authToken; // Store token in process.env for access in tests/fixtures
      Logger.info('API authentication successful. Token stored.');
    } else {
      Logger.warn('API user or password not found in config. Skipping API authentication.');
    }
  } catch (error: any) {
    Logger.error(`API authentication failed: ${error.message}`);
    // Decide if this is a critical failure that should stop tests
    // process.exit(1);
  }
  */

  Logger.info('--- Global Setup Completed Successfully ---');
}

export default globalSetup;