import { FullConfig } from '@playwright/test';
import { Logger } from '@core/logger/Logger'; // Assuming Logger.ts is in core/logger

/**
 * Global teardown function for Playwright.
 * This function runs once after all tests have finished.
 * It's responsible for cleaning up global resources, generating final reports,
 * or performing any other post-test actions.
 *
 * @param config The Playwright FullConfig object.
 */
async function globalTeardown(config: FullConfig) {
  Logger.info('--- Global Teardown Started ---');

  // Example: Clean up any global resources initialized in global-setup
  // - Close database connections
  // - Stop any test servers started manually (if not using Playwright's webServer option)
  // - Generate final test reports or send notifications
  // - Clear any temporary files or caches

  // Example: If an API token was stored in process.env, you might clear it
  if (process.env.AUTH_TOKEN) {
    delete process.env.AUTH_TOKEN;
    Logger.info('Cleaned up API authentication token from environment.');
  }

  Logger.info('--- Global Teardown Completed Successfully ---');
}

export default globalTeardown;