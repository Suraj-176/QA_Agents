import * as dotenv from 'dotenv';
import * as path from 'path';
import { Logger } from '../logger/Logger';

const logger = Logger.getInstance();

/**
 * Interface defining the structure of our application configuration.
 */
interface AppConfig {
  baseURL: string;
  apiBaseURL: string;
  browser: 'chromium' | 'firefox' | 'webkit';
  headless: boolean;
  enableAIHealing: boolean;
  logLevel: 'error' | 'warn' | 'info' | 'debug' | 'verbose';
  retries: number;
  workers: number;
  defaultTimeout: number;
}

/**
 * Config class to manage application settings, loaded from environment variables.
 * Implements a Singleton pattern to ensure a single configuration instance.
 */
export class Config {
  private static instance: Config;
  private config: AppConfig;
  private static isLoaded: boolean = false;

  private constructor() {
    this.config = this.loadConfig();
  }

  /**
   * Loads environment variables from a .env file.
   * This method should be called once at the application start or before accessing config.
   */
  public static load(): void {
    if (!Config.isLoaded) {
      const envPath = path.resolve(process.cwd(), '.env');
      const result = dotenv.config({ path: envPath });

      if (result.error) {
        logger.warn(`No .env file found at ${envPath} or error loading it. Using default environment variables.`);
      } else {
        logger.info(`Environment variables loaded from ${envPath}`);
      }
      Config.isLoaded = true;
    }
  }

  /**
   * Returns the singleton instance of the Config.
   */
  public static getInstance(): Config {
    if (!Config.instance) {
      Config.load(); // Ensure .env is loaded before creating instance
      Config.instance = new Config();
    }
    return Config.instance;
  }

  /**
   * Internal method to load and parse configuration from environment variables.
   * Provides default values if environment variables are not set.
   * @returns The parsed AppConfig object.
   */
  private loadConfig(): AppConfig {
    return {
      baseURL: process.env.BASE_URL || 'https://www.saucedemo.com',
      apiBaseURL: process.env.API_BASE_URL || 'https://api.example.com', // Placeholder for API base URL
      browser: (process.env.BROWSER as AppConfig['browser']) || 'chromium',
      headless: process.env.HEADLESS === 'true' || false,
      enableAIHealing: process.env.ENABLE_AI_HEALING === 'true' || false,
      logLevel: (process.env.LOG_LEVEL as AppConfig['logLevel']) || 'info',
      retries: parseInt(process.env.RETRIES || '0', 10),
      workers: parseInt(process.env.WORKERS || '1', 10),
      defaultTimeout: parseInt(process.env.DEFAULT_TIMEOUT || '30000', 10), // 30 seconds
    };
  }

  /**
   * Retrieves a specific configuration value.
   * @param key The key of the configuration property to retrieve.
   * @returns The value of the configuration property.
   * @throws Error if the key does not exist in the configuration.
   */
  public get<K extends keyof AppConfig>(key: K): AppConfig[K] {
    if (!(key in this.config)) {
      logger.error(`Configuration key "${key}" not found.`);
      throw new Error(`Configuration key "${key}" not found.`);
    }
    return this.config[key];
  }

  /**
   * Reloads the configuration from environment variables.
   * Useful for dynamic changes in long-running processes, though typically not needed for test frameworks.
   */
  public reload(): void {
    this.config = this.loadConfig();
    logger.info('Configuration reloaded.');
  }
}

// Export a singleton instance for easy access
export const config = Config.getInstance();