import { APIRequestContext, APIResponse } from '@playwright/test';
import { ZodSchema, ZodError } from 'zod';
import { Logger } from '../logger/Logger';
import { Config } from '../config/Config';

const logger = Logger.getInstance();
const config = Config.getInstance();

/**
 * Options for API requests, extending Playwright's RequestOptions.
 */
interface APIRequestOptions {
  data?: object | string | Buffer;
  params?: object;
  headers?: { [key: string]: string };
  timeout?: number;
  failOnStatusCode?: boolean;
  ignoreHTTPSErrors?: boolean;
  maxRetries?: number;
  retryDelayMs?: number;
}

/**
 * APIClient provides a wrapper around Playwright's APIRequestContext
 * for making REST API calls with built-in features like:
 * - Retry mechanism
 * - Correlation ID injection
 * - Zod runtime payload validation
 * - Centralized logging
 */
export class APIClient {
  private requestContext: APIRequestContext;
  private defaultMaxRetries: number;
  private defaultRetryDelayMs: number;

  constructor(requestContext: APIRequestContext) {
    this.requestContext = requestContext;
    this.defaultMaxRetries = 3;
    this.defaultRetryDelayMs = 1000; // 1 second
  }

  /**
   * Generates a unique correlation ID for API requests.
   * @returns A string representing the correlation ID.
   */
  private generateCorrelationId(): string {
    return `corr-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;
  }

  /**
   * Executes an API request with retry logic and correlation ID.
   * @param method HTTP method (GET, POST, PUT, DELETE).
   * @param url The endpoint URL.
   * @param options Request options including data, headers, etc.
   * @param schema Optional Zod schema for response validation.
   * @returns The APIResponse object.
   * @throws Error if the request fails after all retries or validation fails.
   */
  private async executeRequest<T>(
    method: 'get' | 'post' | 'put' | 'delete' | 'patch',
    url: string,
    options: APIRequestOptions = {},
    schema?: ZodSchema<T>
  ): Promise<APIResponse> {
    const correlationId = options.headers?.['X-Correlation-ID'] || this.generateCorrelationId();
    const maxRetries = options.maxRetries ?? this.defaultMaxRetries;
    const retryDelayMs = options.retryDelayMs ?? this.defaultRetryDelayMs;
    const fullUrl = `${config.get('apiBaseURL')}${url}`;

    const requestOptions = {
      headers: {
        'Content-Type': 'application/json',
        'X-Correlation-ID': correlationId,
        ...options.headers,
      },
      timeout: options.timeout ?? config.get('defaultTimeout'),
      failOnStatusCode: options.failOnStatusCode ?? true,
      ignoreHTTPSErrors: options.ignoreHTTPSErrors ?? false,
      data: options.data,
      params: options.params,
    };

    logger.info(`[${correlationId}] Sending ${method.toUpperCase()} request to: ${fullUrl}`);
    logger.debug(`[${correlationId}] Request options: ${JSON.stringify(requestOptions)}`);

    for (let i = 0; i <= maxRetries; i++) {
      try {
        const response: APIResponse = await this.requestContext[method](fullUrl, requestOptions);

        logger.info(`[${correlationId}] Received response for ${method.toUpperCase()} ${fullUrl} with status: ${response.status()}`);
        logger.debug(`[${correlationId}] Response headers: ${JSON.stringify(response.headers())}`);

        if (!response.ok()) {
          const errorText = await response.text();
          logger.error(`[${correlationId}] Request failed with status ${response.status()}: ${errorText}`);
          throw new Error(`API request failed with status ${response.status()}: ${errorText}`);
        }

        // Validate response body if a schema is provided
        if (schema) {
          const jsonResponse = await response.json();
          try {
            schema.parse(jsonResponse);
            logger.debug(`[${correlationId}] Response payload validated successfully against schema.`);
          } catch (validationError: unknown) {
            if (validationError instanceof ZodError) {
              logger.error(`[${correlationId}] Response payload validation failed: ${validationError.errors.map(e => `${e.path.join('.')}: ${e.message}`).join(', ')}`);
              throw new Error(`Response payload validation failed: ${validationError.errors.map(e => `${e.path.join('.')}: ${e.message}`).join(', ')}`);
            }
            throw validationError; // Re-throw other types of errors
          }
        }

        return response;
      } catch (error: unknown) {
        logger.warn(`[${correlationId}] Attempt ${i + 1}/${maxRetries + 1} failed for ${method.toUpperCase()} ${fullUrl}. Error: ${(error as Error).message}`);
        if (i < maxRetries) {
          await new Promise(resolve => setTimeout(resolve, retryDelayMs));
        } else {
          logger.error(`[${correlationId}] All ${maxRetries + 1} attempts failed for ${method.toUpperCase()} ${fullUrl}.`);
          throw error; // Re-throw the last error after all retries
        }
      }
    }
    // This line should theoretically not be reached
    throw new Error('Unexpected error: Request execution loop completed without returning or throwing.');
  }

  /**
   * Sends a GET request.
   * @param url The endpoint URL.
   * @param options Request options.
   * @param schema Optional Zod schema for response validation.
   * @returns The APIResponse object.
   */
  public async get<T>(url: string, options?: APIRequestOptions, schema?: ZodSchema<T>): Promise<APIResponse> {
    return this.executeRequest('get', url, options, schema);
  }

  /**
   * Sends a POST request.
   * @param url The endpoint URL.
   * @param data The request body.
   * @param options Request options.
   * @param schema Optional Zod schema for response validation.
   * @returns The APIResponse object.
   */
  public async post<T>(url: string, data: object | string | Buffer, options?: APIRequestOptions, schema?: ZodSchema<T>): Promise<APIResponse> {
    return this.executeRequest('post', url, { ...options, data }, schema);
  }

  /**
   * Sends a PUT request.
   * @param url The endpoint URL.
   * @param data The request body.
   * @param options Request options.
   * @param schema Optional Zod schema for response validation.
   * @returns The APIResponse object.
   */
  public async put<T>(url: string, data: object | string | Buffer, options?: APIRequestOptions, schema?: ZodSchema<T>): Promise<APIResponse> {
    return this.executeRequest('put', url, { ...options, data }, schema);
  }

  /**
   * Sends a DELETE request.
   * @param url The endpoint URL.
   * @param options Request options.
   * @param schema Optional Zod schema for response validation.
   * @returns The APIResponse object.
   */
  public async delete<T>(url: string, options?: APIRequestOptions, schema?: ZodSchema<T>): Promise<APIResponse> {
    return this.executeRequest('delete', url, options, schema);
  }

  /**
   * Sends a PATCH request.
   * @param url The endpoint URL.
   * @param data The request body.
   * @param options Request options.
   * @param schema Optional Zod schema for response validation.
   * @returns The APIResponse object.
   */
  public async patch<T>(url: string, data: object | string | Buffer, options?: APIRequestOptions, schema?: ZodSchema<T>): Promise<APIResponse> {
    return this.executeRequest('patch', url, { ...options, data }, schema);
  }
}