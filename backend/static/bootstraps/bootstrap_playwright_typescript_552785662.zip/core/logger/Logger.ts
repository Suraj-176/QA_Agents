import winston from 'winston';
import 'winston-daily-rotate-file';
import * as path from 'path';
import { Config } from '../config/Config';

/**
 * Sensitive data masking filter for logs.
 * Redacts common sensitive patterns like credit card numbers, passwords, API tokens, SSN.
 */
const sensitiveDataMasking = winston.format((info) => {
  const mask = (text: string): string => {
    // Credit Card Numbers (13-16 digits, with or without spaces/hyphens)
    text = text.replace(/(\b(?:\d[ -]*?){13,16}\b)/g, '************');
    // Passwords (common patterns like "password=", "pwd=", "token=")
    text = text.replace(/(password|pwd|token|secret|api_key|auth_token)=['"]?([a-zA-Z0-9!@#$%^&*()_+-=\[\]{}|;:'",.<>/?`~]{4,})['"]?/gi, '$1=********');
    // Bearer Tokens (JWT-like patterns)
    text = text.replace(/(Bearer\s)([a-zA-Z0-9-_]+\.[a-zA-Z0-9-_]+\.[a-zA-Z0-9-_]+)/g, '$1[REDACTED_JWT]');
    // Social Security Numbers (XXX-XX-XXXX)
    text = text.replace(/\b\d{3}-\d{2}-\d{4}\b/g, 'XXX-XX-XXXX');
    // PAN numbers (similar to CC, but broader context)
    text = text.replace(/\bPAN:\s*(\d{4}[ -]?){3}\d{4}\b/g, 'PAN: ************');
    return text;
  };

  if (info.message) {
    info.message = mask(info.message);
  }
  if (info.stack) {
    info.stack = mask(info.stack);
  }
  return info;
});

/**
 * Logger class for centralized logging with sensitive data masking and daily rotation.
 * Implements a Singleton pattern to ensure a single instance of the logger throughout the application.
 */
export class Logger {
  private static instance: Logger;
  private readonly logger: winston.Logger;

  private constructor() {
    // Ensure config is loaded before accessing log level
    Config.load();
    const logLevel = Config.get('logLevel');
    const logsDir = path.join(process.cwd(), 'logs');

    // Daily rotate file transport
    const fileTransport = new winston.transports.DailyRotateFile({
      filename: 'application-%DATE%.log',
      datePattern: 'YYYY-MM-DD',
      dirname: logsDir,
      zippedArchive: true,
      maxSize: '20m', // Max size of 20MB
      maxFiles: '14d', // Retain logs for 14 days
      level: logLevel,
    });

    this.logger = winston.createLogger({
      level: logLevel,
      format: winston.format.combine(
        sensitiveDataMasking(), // Apply sensitive data masking
        winston.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
        winston.format.errors({ stack: true }),
        winston.format.splat(),
        winston.format.json()
      ),
      transports: [
        fileTransport,
        new winston.transports.Console({
          format: winston.format.combine(
            sensitiveDataMasking(), // Apply sensitive data masking
            winston.format.colorize(),
            winston.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
            winston.format.printf(
              ({ level, message, timestamp, stack }) => {
                if (stack) {
                  return `${timestamp} ${level}: ${message}\n${stack}`;
                }
                return `${timestamp} ${level}: ${message}`;
              }
            )
          ),
          level: logLevel,
        }),
      ],
      exitOnError: false, // Do not exit on handled exceptions
    });
  }

  /**
   * Returns the singleton instance of the Logger.
   */
  public static getInstance(): Logger {
    if (!Logger.instance) {
      Logger.instance = new Logger();
    }
    return Logger.instance;
  }

  /**
   * Logs an informational message.
   * @param message The message to log.
   * @param meta Optional metadata.
   */
  public info(message: string, meta?: any): void {
    this.logger.info(message, meta);
  }

  /**
   * Logs a warning message.
   * @param message The message to log.
   * @param meta Optional metadata.
   */
  public warn(message: string, meta?: any): void {
    this.logger.warn(message, meta);
  }

  /**
   * Logs an error message.
   * @param message The message to log.
   * @param error The error object (optional, but recommended for errors).
   * @param meta Optional metadata.
   */
  public error(message: string, error?: Error | unknown, meta?: any): void {
    if (error instanceof Error) {
      this.logger.error(message, { ...meta, stack: error.stack, name: error.name });
    } else if (typeof error === 'string') {
      this.logger.error(message, { ...meta, error: error });
    } else {
      this.logger.error(message, meta);
    }
  }

  /**
   * Logs a debug message.
   * @param message The message to log.
   * @param meta Optional metadata.
   */
  public debug(message: string, meta?: any): void {
    this.logger.debug(message, meta);
  }

  /**
   * Logs a verbose message.
   * @param message The message to log.
   * @param meta Optional metadata.
   */
  public verbose(message: string, meta?: any): void {
    this.logger.verbose(message, meta);
  }
}

// Export a singleton instance for easy access
export const logger = Logger.getInstance();