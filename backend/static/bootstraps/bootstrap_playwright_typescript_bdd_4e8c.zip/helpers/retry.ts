import { Logger } from '../core/logger/Logger'; // Assuming Logger is in core/logger

/**
 * Options for the retry helper function.
 */
interface RetryOptions {
  /** Maximum number of attempts to execute the operation. Defaults to 3. */
  maxAttempts?: number;
  /** Delay in milliseconds between retries. Defaults to 1000ms (1 second). */
  delayMs?: number;
  /** Custom error message to throw if the operation fails after all retries. */
  errorMessage?: string;
  /** Whether to log each attempt. Defaults to true. */
  logAttempts?: boolean;
  /** A predicate function to determine if an error should trigger a retry.
   * If not provided, all errors will trigger a retry.
   */
  shouldRetry?: (error: any) => boolean;
}

const defaultRetryOptions: RetryOptions = {
  maxAttempts: 3,
  delayMs: 1000, // 1 second
  errorMessage: 'Operation failed after multiple retries.',
  logAttempts: true,
  shouldRetry: () => true, // By default, retry on any error
};

/**
 * Retries an asynchronous operation a specified number of times with a delay between attempts.
 * This helper is useful for handling flaky operations like API calls, UI interactions, or database queries.
 *
 * @template T The expected return type of the operation.
 * @param operation The asynchronous function to retry.
 * @param options Optional retry configuration.
 * @returns A Promise that resolves with the result of the successful operation.
 * @throws An Error if the operation fails after all retries.
 */
export async function retry<T>(
  operation: () => Promise<T>,
  options?: RetryOptions
): Promise<T> {
  const logger = new Logger('RetryHelper');
  const opts = { ...defaultRetryOptions, ...options };
  const { maxAttempts, delayMs, errorMessage, logAttempts, shouldRetry } = opts;

  for (let attempt = 1; attempt <= maxAttempts!; attempt++) {
    try {
      if (logAttempts) {
        logger.debug(`Attempt ${attempt}/${maxAttempts} for operation.`);
      }
      return await operation();
    } catch (error: any) {
      if (shouldRetry!(error) && attempt < maxAttempts!) {
        logger.warn(`Operation failed on attempt ${attempt}/${maxAttempts}. Retrying in ${delayMs}ms. Error: ${error.message}`);
        await new Promise(resolve => setTimeout(resolve, delayMs));
      } else {
        logger.error(`Operation failed after ${attempt} attempts (max ${maxAttempts}). Final error: ${error.message}`);
        throw new Error(errorMessage || `Operation failed after ${maxAttempts} attempts: ${error.message}`);
      }
    }
  }
  // This line should theoretically not be reached if maxAttempts is >= 1 and an error is always thrown on failure.
  // Added for type safety and extreme edge cases.
  throw new Error(errorMessage || 'Retry function completed without returning a value or throwing an error.');
}