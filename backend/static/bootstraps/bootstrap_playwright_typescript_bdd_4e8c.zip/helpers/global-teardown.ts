import { FullConfig } from '@playwright/test';
import { Logger } from '../core/logger/Logger'; // Assuming Logger is in core/logger
import { Config } from '../core/config/Config'; // Assuming Config is in core/config

/**
 * Global teardown function for the Playwright test framework.
 * This function runs once after all tests have completed.
 * It's used for cleaning up global resources and logging framework shutdown.
 * @param config The Playwright FullConfig object.
 */
async function globalTeardown(config: FullConfig) {
  const logger = new Logger('GlobalTeardown');
  logger.info('🧹 Starting global teardown...');

  // Access configuration if needed for teardown logic
  const appConfig = Config.get();
  logger.info(`Environment: ${appConfig.environment}`);

  // --- Add any enterprise-specific global teardown logic here ---
  // Examples:
  // - Close shared database connections
  // - Shut down mock servers or external services
  // - Generate consolidated test reports or metrics
  // - Clean up temporary files or test data created during the run
  // - Send final notifications or status updates

  logger.info('🎉 Global teardown completed.');
}

export default globalTeardown;