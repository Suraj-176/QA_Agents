import { FullConfig } from '@playwright/test';
import { Logger } from '../core/logger/Logger'; // Assuming Logger is in core/logger
import { Config } from '../core/config/Config'; // Assuming Config is in core/config

/**
 * Global setup function for the Playwright test framework.
 * This function runs once before all tests.
 * It's used for initializing global resources, loading configuration, and logging framework startup.
 * @param config The Playwright FullConfig object.
 */
async function globalSetup(config: FullConfig) {
  const logger = new Logger('GlobalSetup');
  logger.info('🚀 Starting global setup...');

  // Load and log application configuration
  // Assuming Config.get() provides access to the loaded configuration,
  // which might have been initialized by playwright.config.ts or needs explicit loading here.
  const appConfig = Config.get();
  logger.info(`Environment: ${appConfig.environment}`);
  logger.info(`Base URL: ${appConfig.baseUrl}`);

  // --- Add any enterprise-specific global setup logic here ---
  // Examples:
  // - Initialize a shared database connection pool
  // - Set up a global API client instance
  // - Perform initial authentication and save storage state for reuse (if not handled per test)
  // - Clean up any previous test run artifacts
  // - Start mock servers or external services

  logger.info('✅ Global setup completed.');
}

export default globalSetup;