import * as dotenv from 'dotenv';
import { logger } from '../logger/Logger';

/**
 * Config class to manage environment variables and application settings.
 * Implements a singleton pattern to ensure a single source of truth for configurations.
 */
export class Config {
  private static instance: Config;
  private readonly env: NodeJS.ProcessEnv;

  private constructor() {
    this.env = process.env;
    this.validateConfig();
  }

  /**
   * Loads environment variables from a .env file.
   * This method should be called once at the application start (e.g., in global-setup.ts).
   */
  public static loadEnvironmentVariables(): void {
    dotenv.config({ path: '.env' });
    logger.info('Environment variables loaded.');
  }

  /**
   * Returns the singleton instance of the Config.
   */
  public static getInstance(): Config {
    if (!Config.instance) {
      Config.instance = new Config();
    }
    return Config.instance;
  }

  /**
   * Validates critical environment variables.
   * Throws an error if any required variable is missing.
   */
  private validateConfig(): void {
    const requiredEnvVars = ['BASE_URL', 'API_URL'];
    const missingVars: string[] = [];

    requiredEnvVars.forEach(key => {
      if (!this.env[key]) {
        missingVars.push(key);
      }
    });

    if (missingVars.length > 0) {
      const errorMessage = `Missing required environment variables: ${missingVars.join(', ')}. Please check your .env file.`;
      logger.error(errorMessage);
      throw new Error(errorMessage);
    }
    logger.info('Environment variables validated successfully.');
  }

  /**
   * Retrieves the base URL for UI tests.
   * @returns The base URL string.
   */
  public static getBaseUrl(): string {
    return Config.getInstance().env.BASE_URL as string;
  }

  /**
   * Retrieves the base URL for API tests.
   * @returns The API URL string.
   */
  public static getApiUrl(): string {
    return Config.getInstance().env.API_URL as string;
  }

  /**
   * Retrieves the default timeout for Playwright actions and navigations.
   * @returns The timeout in milliseconds. Defaults to 30000ms (30 seconds).
   */
  public static getTimeout(): number {
    return parseInt(Config.getInstance().env.PLAYWRIGHT_TIMEOUT || '30000', 10);
  }

  /**
   * Checks if AI healing is enabled.
   * @returns True if AI healing is enabled, false otherwise.
   */
  public static isAiHealingEnabled(): boolean {
    return Config.getInstance().env.ENABLE_AI_HEALING === 'true';
  }

  /**
   * Checks if tests should run in headless mode.
   * @returns True if headless mode is enabled, false otherwise. Defaults to true.
   */
  public static isHeadless(): boolean {
    return Config.getInstance().env.HEADLESS !== 'false';
  }

  /**
   * Retrieves a specific environment variable.
   * @param key The name of the environment variable.
   * @param defaultValue An optional default value if the variable is not set.
   * @returns The value of the environment variable or the default value.
   */
  public static getEnv(key: string, defaultValue?: string): string | undefined {
    return Config.getInstance().env[key] || defaultValue;
  }
}