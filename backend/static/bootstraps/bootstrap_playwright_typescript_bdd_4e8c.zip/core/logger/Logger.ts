import winston from 'winston';
import 'winston-daily-rotate-file';
import * as path from 'path';
import * as fs from 'fs';

/**
 * Logger class for robust, sensitive-data-masked logging.
 * Implements a singleton pattern and daily log rotation.
 */
export class Logger {
  private static instance: Logger;
  private readonly logger: winston.Logger;
  private readonly logsDir: string = path.join(process.cwd(), 'logs');

  // Regex patterns for sensitive data masking
  private readonly sensitiveDataPatterns: RegExp[] = [
    /\b(?:\d[ -]*?){13,16}\b/g, // Credit Card Numbers (13-16 digits, with optional spaces/hyphens)
    /\b(?:[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})\b/g, // Email addresses
    /(password|passwd|pwd|secret|token|apikey|auth|authorization)\s*[:=]\s*['"]?([a-zA-Z0-9!@#$%^&*()_+-=\[\]{};':"\\|,.<>\/?`~]{6,})['"]?/gi, // Passwords, API keys, tokens
    /\b\d{3}[- ]?\d{2}[- ]?\d{4}\b/g, // Social Security Numbers (XXX-XX-XXXX)
    /\b(?:4[0-9]{12}(?:[0-9]{3})?|5[1-5][0-9]{14}|6(?:011|5[0-9]{2})[0-9]{12}|3[47][0-9]{13}|3(?:0[0-5]|[68][0-9])[0-9]{11}|(?:2131|1800|35\d{3})\d{11})\b/g, // PAN numbers (common credit card prefixes)
  ];

  private constructor() {
    // Ensure logs directory exists
    if (!fs.existsSync(this.logsDir)) {
      fs.mkdirSync(this.logsDir);
    }

    // Custom format for sensitive data masking
    const sensitiveDataMaskingFormat = winston.format((info) => {
      let message = info.message;
      this.sensitiveDataPatterns.forEach(pattern => {
        message = message.replace(pattern, (match) => {
          // Replace with asterisks, keeping a few characters for context if possible
          const visibleChars = Math.min(4, Math.floor(match.length / 2));
          return match.substring(0, visibleChars) + '*'.repeat(match.length - visibleChars);
        });
      });
      info.message = message;
      return info;
    });

    this.logger = winston.createLogger({
      level: process.env.LOG_LEVEL || 'info', // Default log level
      format: winston.format.combine(
        winston.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
        sensitiveDataMaskingFormat(), // Apply sensitive data masking
        winston.format.printf(({ level, message, timestamp, ...metadata }) => {
          let msg = `${timestamp} [${level.toUpperCase()}]: ${message}`;
          if (Object.keys(metadata).length) {
            msg += ` ${JSON.stringify(metadata)}`;
          }
          return msg;
        })
      ),
      transports: [
        // Console transport
        new winston.transports.Console({
          format: winston.format.combine(
            winston.format.colorize(),
            winston.format.simple()
          ),
        }),
        // Daily rotate file transport for all logs
        new winston.transports.DailyRotateFile({
          filename: path.join(this.logsDir, 'application-%DATE%.log'),
          datePattern: 'YYYY-MM-DD',
          zippedArchive: true,
          maxSize: '20m', // Max size of 20MB
          maxFiles: '14d', // Retain logs for 14 days
          level: 'info',
        }),
        // Daily rotate file transport for error logs only
        new winston.transports.DailyRotateFile({
          filename: path.join(this.logsDir, 'error-%DATE%.log'),
          datePattern: 'YYYY-MM-DD',
          zippedArchive: true,
          maxSize: '20m',
          maxFiles: '14d',
          level: 'error',
        }),
      ],
      exitOnError: false, // Do not exit on handled exceptions
    });
  }

  /**
   * Returns the singleton instance of the Logger.
   */
  public static getInstance(): Logger {
    if (!Logger.instance) {
      Logger.instance = new Logger();
    }
    return Logger.instance;
  }

  /**
   * Logs an informational message.
   * @param message The message to log.
   * @param meta Optional metadata.
   */
  public info(message: string, meta?: Record<string, any>): void {
    this.logger.info(message, meta);
  }

  /**
   * Logs a warning message.
   * @param message The message to log.
   * @param meta Optional metadata.
   */
  public warn(message: string, meta?: Record<string, any>): void {
    this.logger.warn(message, meta);
  }

  /**
   * Logs an error message.
   * @param message The message to log.
   * @param error Optional error object.
   * @param meta Optional metadata.
   */
  public error(message: string, error?: Error, meta?: Record<string, any>): void {
    this.logger.error(message, { error: error?.message, stack: error?.stack, ...meta });
  }

  /**
   * Logs a debug message.
   * @param message The message to log.
   * @param meta Optional metadata.
   */
  public debug(message: string, meta?: Record<string, any>): void {
    this.logger.debug(message, meta);
  }

  /**
   * Logs a verbose message.
   * @param message The message to log.
   * @param meta Optional metadata.
   */
  public verbose(message: string, meta?: Record<string, any>): void {
    this.logger.verbose(message, meta);
  }
}

// Export the singleton instance for easy access
export const logger = Logger.getInstance();