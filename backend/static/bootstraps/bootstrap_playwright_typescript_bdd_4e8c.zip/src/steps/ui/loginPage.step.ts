import { Given, When, Then } from '@cucumber/cucumber';
import { Page, expect } from '@playwright/test';
import { LoginPage } from '../../pages/loginPage';
import { LoginValidator } from '../../helpers/validators/LoginValidator';
import { Config } from '../../core/config/Config';
import { Logger } from '../../core/logger/Logger';
import * as allure from 'allure-playwright';

// Define a custom World interface to extend Cucumber's World with Playwright's Page
interface CustomWorld {
    page: Page;
    // Add other shared objects like context, browser, etc. if needed
}

let loginPage: LoginPage;
let loginValidator: LoginValidator;

Given('I am on the login page', async function (this: CustomWorld) {
    await allure.step('Navigate to login page', async () => {
        Logger.info('Navigating to login page.');
        loginPage = new LoginPage(this.page);
        loginValidator = new LoginValidator(this.page); // Initialize validator with the page for UI checks
        await loginPage.navigate();
        await expect(this.page).toHaveURL(new RegExp('.*/login')); // Basic URL check
    });
});

When('I enter valid credentials', async function (this: CustomWorld) {
    await allure.step('Enter valid credentials', async () => {
        Logger.info('Entering valid credentials.');
        const username = Config.get('validUser.username');
        const password = Config.get('validUser.password');
        await loginPage.enterUsername(username);
        await loginPage.enterPassword(password);
    });
});

When('I enter invalid credentials', async function (this: CustomWorld) {
    await allure.step('Enter invalid credentials', async () => {
        Logger.info('Entering invalid credentials.');
        const username = Config.get('invalidUser.username');
        const password = Config.get('invalidUser.password');
        await loginPage.enterUsername(username);
        await loginPage.enterPassword(password);
    });
});

When('I click the login button', async function (this: CustomWorld) {
    await allure.step('Click login button', async () => {
        Logger.info('Clicking login button.');
        await loginPage.clickLogin();
    });
});

Then('I should be logged in successfully', async function (this: CustomWorld) {
    await allure.step('Verify successful login', async () => {
        Logger.info('Verifying successful login.');
        const isLoggedIn = await loginValidator.isLoginSuccessful();
        expect(isLoggedIn).toBe(true, 'User should be logged in successfully.');
    });
});

Then('I should see an error message {string}', async function (this: CustomWorld, expectedMessage: string) {
    await allure.step(`Verify error message: "${expectedMessage}"`, async () => {
        Logger.info(`Verifying error message: "${expectedMessage}".`);
        const isErrorMessageDisplayed = await loginValidator.isLoginErrorMessageDisplayed(expectedMessage);
        expect(isErrorMessageDisplayed).toBe(true, `Error message "${expectedMessage}" should be displayed.`);
    });
});

Then('I should not be logged in', async function (this: CustomWorld) {
    await allure.step('Verify not logged in', async () => {
        Logger.info('Verifying user is not logged in.');
        const isLoggedIn = await loginValidator.isLoginSuccessful();
        expect(isLoggedIn).toBe(false, 'User should not be logged in.');
    });
});