import { Page, Locator } from '@playwright/test';
import { BasePage } from './basePage'; // Assuming BasePage exists in src/pages/basePage.ts
import { Config } from '../../core/config/Config';

/**
 * Represents the Login Page Object Model (POM).
 * Extends BasePage for common page functionalities and uses fluent returns.
 */
export class LoginPage extends BasePage {
    private readonly usernameInput: Locator;
    private readonly passwordInput: Locator;
    private readonly loginButton: Locator;
    private readonly errorMessage: Locator;
    private readonly welcomeMessage: Locator; // Element to confirm successful login

    constructor(page: Page) {
        super(page);
        this.usernameInput = page.locator('#username'); // Example locator
        this.passwordInput = page.locator('#password'); // Example locator
        this.loginButton = page.locator('#login-button'); // Example locator
        this.errorMessage = page.locator('.error-message'); // Example locator
        this.welcomeMessage = page.locator('.welcome-message'); // Example locator, e.g., "Welcome, User!"
    }

    /**
     * Navigates to the login page.
     * @returns {Promise<LoginPage>} - Returns the current LoginPage instance for fluent chaining.
     */
    async navigate(): Promise<LoginPage> {
        await this.page.goto(Config.get('baseUrl') + '/login');
        return this;
    }

    /**
     * Enters the username into the username input field.
     * @param {string} username - The username to enter.
     * @returns {Promise<LoginPage>} - Returns the current LoginPage instance for fluent chaining.
     */
    async enterUsername(username: string): Promise<LoginPage> {
        await this.usernameInput.fill(username);
        return this;
    }

    /**
     * Enters the password into the password input field.
     * @param {string} password - The password to enter.
     * @returns {Promise<LoginPage>} - Returns the current LoginPage instance for fluent chaining.
     */
    async enterPassword(password: string): Promise<LoginPage> {
        await this.passwordInput.fill(password);
        return this;
    }

    /**
     * Clicks the login button.
     * @returns {Promise<LoginPage>} - Returns the current LoginPage instance for fluent chaining.
     */
    async clickLogin(): Promise<LoginPage> {
        await this.loginButton.click();
        return this;
    }

    /**
     * Performs a full login action by entering credentials and clicking the login button.
     * @param {string} username - The username.
     * @param {string} password - The password.
     * @returns {Promise<LoginPage>} - Returns the current LoginPage instance for fluent chaining.
     */
    async login(username: string, password: string): Promise<LoginPage> {
        await this.enterUsername(username);
        await this.enterPassword(password);
        await this.clickLogin();
        return this;
    }

    /**
     * Gets the text content of the error message element.
     * @returns {Promise<string | null>} - The error message text, or null if the element is not visible.
     */
    async getErrorMessage(): Promise<string | null> {
        if (await this.errorMessage.isVisible()) {
            return this.errorMessage.textContent();
        }
        return null;
    }

    /**
     * Checks if the user is successfully logged in by verifying the visibility of a welcome message.
     * @returns {Promise<boolean>} - True if the welcome message is visible, false otherwise.
     */
    async isLoggedIn(): Promise<boolean> {
        return this.welcomeMessage.isVisible();
    }
}