Feature: UI Login Functionality

  Scenario: Successful User Login
    Given I am on the login page
    When I enter valid credentials
    And I click the login button
    Then I should be logged in successfully

  Scenario: Failed User Login with Invalid Credentials
    Given I am on the login page
    When I enter invalid credentials
    And I click the login button
    Then I should see an error message "Invalid username or password."
    And I should not be logged in