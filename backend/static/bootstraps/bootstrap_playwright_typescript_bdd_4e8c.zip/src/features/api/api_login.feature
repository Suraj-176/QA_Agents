Feature: API Login Functionality

  Scenario: Successful API Login
    When I send a POST request to the login API with valid credentials
    Then the API response status should be 200
    And the API response should contain an access token

  Scenario: Failed API Login with Invalid Credentials
    When I send a POST request to the login API with invalid credentials
    Then the API response status should be 401
    And the API response should contain an error message