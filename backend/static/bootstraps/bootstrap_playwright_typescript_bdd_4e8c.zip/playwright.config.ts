import { defineConfig, devices } from '@playwright/test';
import { defineBddConfig } from 'playwright-bdd';
import { Config } from './core/config/Config';
import * as path from 'path';

// Load environment variables from .env file
Config.loadEnvironmentVariables();

// Define BDD configuration
const testDir = defineBddConfig({
  paths: ['features/**/*.feature'],
  require: ['step-definitions/**/*.ts'],
  // Optional: Specify output directory for generated test files
  outputDir: '.bddgen',
});

/**
 * See https://playwright.dev/docs/test-configuration.
 */
export default defineConfig({
  // Test directory for BDD feature files and generated tests
  testDir,
  /* Folder for test artifacts such as screenshots, videos, traces, etc. */
  outputDir: 'test-results',

  /* Run tests in files in parallel */
  fullyParallel: true,
  /* Fail the build on CI if you accidentally left test.only in the source code. */
  forbidOnly: !!process.env.CI,
  /* Retry on CI only */
  retries: process.env.CI ? 2 : 0,
  /* Opt out of parallel tests on CI. */
  workers: process.env.CI ? 1 : undefined,

  /* Reporter to use. See https://playwright.dev/docs/test-reporters */
  reporter: [
    ['html', { open: 'never' }], // Playwright's built-in HTML reporter
    ['list'], // Console list reporter
    ['allure-playwright', {
      detail: true,
      outputFolder: 'allure-results',
      suiteTitle: false,
    }], // Allure reporter for detailed reports
  ],

  /* Shared settings for all the projects below. See https://playwright.dev/docs/api/class-testoptions. */
  use: {
    /* Base URL to use in actions like `await page.goto('/')`. */
    baseURL: Config.getBaseUrl(),

    /* Collect trace when retrying the first time. See https://playwright.dev/docs/trace-viewer */
    trace: 'on-first-retry',

    /* Headless mode for browsers. Can be overridden by environment variable. */
    headless: Config.isHeadless(),

    /* Global timeout for actions and navigations. */
    actionTimeout: Config.getTimeout(),
    navigationTimeout: Config.getTimeout(),

    /* Viewport size for browser. */
    viewport: { width: 1920, height: 1080 },

    /* Screenshot on failure */
    screenshot: 'only-on-failure',

    /* Video recording */
    video: 'on-first-retry',

    /* Context options for API testing */
    extraHTTPHeaders: {
      'Accept': 'application/json',
      'X-Correlation-ID': `playwright-${Date.now()}`, // Example correlation ID
    },
  },

  /* Configure projects for different browsers and environments */
  projects: [
    {
      name: 'chromium',
      use: { ...devices['Desktop Chrome'] },
      testMatch: '**/*.feature.spec.ts', // Only run BDD tests for UI
    },
    {
      name: 'firefox',
      use: { ...devices['Desktop Firefox'] },
      testMatch: '**/*.feature.spec.ts',
    },
    {
      name: 'webkit',
      use: { ...devices['Desktop Safari'] },
      testMatch: '**/*.feature.spec.ts',
    },
    {
      name: 'api',
      testMatch: 'tests/api/**/*.spec.ts', // Separate project for API-only tests
      use: {
        baseURL: Config.getApiUrl(),
        // No browser needed for API tests
        browserName: 'chromium', // Playwright requires a browserName, but it won't be launched for API tests
        headless: true,
        launchOptions: {
          args: ['--disable-gpu', '--no-sandbox', '--disable-setuid-sandbox'],
        },
      },
    },
  ],

  /* Global setup and teardown for the test environment */
  globalSetup: require.resolve('./global-setup'),
  globalTeardown: require.resolve('./global-teardown'),
});