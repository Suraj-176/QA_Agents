import json
import uuid
from typing import Any, Dict, Optional, Type, TypeVar, Callable
from playwright.sync_api import APIRequestContext, Playwright
from pydantic import BaseModel, ValidationError
from core.config.Config import app_config
from core.logger.Logger import log

T = TypeVar("T", bound=BaseModel)

class APIClient:
    """
    Playwright context-based REST request client containing generic post/get/put/delete
    wrappers with built-in retry blocks, correlation ID injects, and Pydantic runtime
    payload validators.
    """
    def __init__(self, playwright: Playwright):
        """
        Initializes the APIClient with a Playwright instance to create an APIRequestContext.
        """
        self.playwright = playwright
        self.api_context: APIRequestContext = self.playwright.request.new_context(
            base_url=app_config.api_base_url,
            extra_http_headers=app_config.api_default_headers,
            timeout=app_config.timeout_ms
        )
        log.info(f"APIClient initialized with base URL: {app_config.api_base_url}")

    def _generate_correlation_id(self) -> str:
        """Generates a unique correlation ID for requests."""
        return str(uuid.uuid4())

    def _validate_payload(self, payload: Dict[str, Any], schema: Type[T]) -> T:
        """
        Validates a payload against a Pydantic schema.
        Raises ValidationError if validation fails.
        """
        try:
            return schema(**payload)
        except ValidationError as e:
            log.error(f"Payload validation failed: {e.errors()}")
            raise

    def _execute_request(
        self,
        method: str,
        url: str,
        data: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, Any]] = None,
        schema: Optional[Type[T]] = None,
        retries: int = app_config.retries,
        **kwargs
    ) -> Any:
        """
        Internal method to execute an HTTP request with retry logic and correlation ID.
        """
        correlation_id = self._generate_correlation_id()
        request_headers = {
            "X-Correlation-ID": correlation_id,
            **(headers or {})
        }

        log.info(f"[{correlation_id}] Sending {method} request to: {url}")
        log.debug(f"[{correlation_id}] Request Headers: {request_headers}")
        if data:
            log.debug(f"[{correlation_id}] Request Body: {json.dumps(data)}")
        if params:
            log.debug(f"[{correlation_id}] Request Params: {params}")

        for attempt in range(retries + 1):
            try:
                response = None
                if method.lower() == "get":
                    response = self.api_context.get(url, params=params, headers=request_headers, **kwargs)
                elif method.lower() == "post":
                    response = self.api_context.post(url, data=json.dumps(data) if data else None, params=params, headers=request_headers, **kwargs)
                elif method.lower() == "put":
                    response = self.api_context.put(url, data=json.dumps(data) if data else None, params=params, headers=request_headers, **kwargs)
                elif method.lower() == "delete":
                    response = self.api_context.delete(url, params=params, headers=request_headers, **kwargs)
                else:
                    raise ValueError(f"Unsupported HTTP method: {method}")

                response.raise_for_status() # Raises an exception for 4xx/5xx responses

                response_json = response.json()
                log.info(f"[{correlation_id}] Received response (Status: {response.status}) from: {url}")
                log.debug(f"[{correlation_id}] Response Body: {json.dumps(response_json)}")

                if schema:
                    return self._validate_payload(response_json, schema)
                return response_json

            except Exception as e:
                log.warning(f"[{correlation_id}] Attempt {attempt + 1}/{retries + 1} failed for {method} {url}: {e}")
                if attempt == retries:
                    log.error(f"[{correlation_id}] All {retries + 1} attempts failed for {method} {url}.")
                    raise
        return None # Should not be reached

    def get(
        self,
        url: str,
        params: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, Any]] = None,
        schema: Optional[Type[T]] = None,
        **kwargs
    ) -> Any:
        """Performs a GET request."""
        return self._execute_request("GET", url, params=params, headers=headers, schema=schema, **kwargs)

    def post(
        self,
        url: str,
        data: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, Any]] = None,
        schema: Optional[Type[T]] = None,
        **kwargs
    ) -> Any:
        """Performs a POST request."""
        return self._execute_request("POST", url, data=data, params=params, headers=headers, schema=schema, **kwargs)

    def put(
        self,
        url: str,
        data: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, Any]] = None,
        schema: Optional[Type[T]] = None,
        **kwargs
    ) -> Any:
        """Performs a PUT request."""
        return self._execute_request("PUT", url, data=data, params=params, headers=headers, schema=schema, **kwargs)

    def delete(
        self,
        url: str,
        params: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, Any]] = None,
        schema: Optional[Type[T]] = None,
        **kwargs
    ) -> Any:
        """Performs a DELETE request."""
        return self._execute_request("DELETE", url, params=params, headers=headers, schema=schema, **kwargs)

    def dispose(self):
        """Disposes the APIRequestContext."""
        if self.api_context:
            self.api_context.dispose()
            log.info("APIRequestContext disposed.")

# Example Pydantic schema for demonstration
class UserSchema(BaseModel):
    id: int
    name: str
    email: str

# Example usage (can be used in fixtures or directly in tests)
# from playwright.sync_api import sync_playwright
# with sync_playwright() as p:
#     api_client = APIClient(p)
#     try:
#         # Example GET request with schema validation
#         user = api_client.get("/users/1", schema=UserSchema)
#         print(f"Fetched user: {user.name}")
#
#         # Example POST request
#         new_user_data = {"name": "Test User", "email": "test@example.com"}
#         created_user = api_client.post("/users", data=new_user_data, schema=UserSchema)
#         print(f"Created user: {created_user.id}")
#     except Exception as e:
#         print(f"API call failed: {e}")
#     finally:
#         api_client.dispose()