import re
import os
from loguru import logger
from datetime import datetime

class Logger:
    """
    Singleton Logger class with sensitive data masking and daily log rotation.
    It uses loguru for robust logging capabilities.
    """
    _instance = None
    _initialized = False

    # Regex patterns for sensitive data masking
    # This list can be extended as needed
    SENSITIVE_PATTERNS = [
        re.compile(r'\b(?:\d[ -]*?){13,16}\b'),  # Credit Card Numbers (13-16 digits)
        re.compile(r'(password|pwd|secret|token|api_key|auth_key|pin)\s*[:=]\s*[\'"]?([^\s\'"]+)[\'"]?', re.IGNORECASE), # Passwords, API tokens
        re.compile(r'\b\d{3}[- ]?\d{2}[- ]?\d{4}\b'),  # Social Security Numbers (XXX-XX-XXXX)
        re.compile(r'\b[A-Z0-9]{20,}\b'), # Generic long alphanumeric strings that might be tokens
    ]

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self):
        if not self._initialized:
            self._initialized = True
            self._setup_logger()

    def _mask_sensitive_data(self, record):
        """
        Filter function to mask sensitive data in log records.
        """
        message = record["message"]
        for pattern in self.SENSITIVE_PATTERNS:
            # For patterns that capture groups (like password/token), replace with masked group
            if pattern.groups > 0:
                message = pattern.sub(lambda m: m.group(1) + ": ********", message)
            else:
                message = pattern.sub("********", message)
        record["message"] = message
        return True

    def _setup_logger(self):
        """
        Configures the loguru logger with file rotation, formatting, and sensitive data masking.
        """
        # Remove default handler to prevent duplicate logs
        logger.remove()

        log_dir = "logs"
        os.makedirs(log_dir, exist_ok=True)

        # Configure file logger with daily rotation and sensitive data masking
        log_file_path = os.path.join(log_dir, f"automation_{datetime.now().strftime('%Y-%m-%d')}.log")
        logger.add(
            log_file_path,
            rotation="1 day",  # Rotate daily
            compression="zip", # Compress old logs
            level="INFO",
            format="{time:YYYY-MM-DD HH:mm:ss.SSS} | {level: <8} | {file}:{line} | {message}",
            filter=self._mask_sensitive_data, # Apply sensitive data masking
            enqueue=True, # Use a queue for non-blocking logging
            backtrace=True, # Show full stack trace on error
            diagnose=True, # Show variable values in stack trace
        )

        # Configure console logger (optional, can be removed if only file logging is desired)
        logger.add(
            os.sys.stderr,
            level="INFO",
            format="<green>{time:YYYY-MM-DD HH:mm:ss.SSS}</green> | <level>{level: <8}</level> | <cyan>{file}</cyan>:<cyan>{line}</cyan> | <level>{message}</level>",
            filter=self._mask_sensitive_data, # Apply sensitive data masking
        )

        self.logger = logger

    def get_logger(self):
        """
        Returns the configured loguru logger instance.
        """
        return self.logger

# Instantiate the logger once
log = Logger().get_logger()