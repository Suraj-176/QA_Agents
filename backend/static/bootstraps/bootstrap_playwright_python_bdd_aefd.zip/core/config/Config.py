import os
from dotenv import load_dotenv
from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict

# Load environment variables from .env file
load_dotenv()

class Config(BaseSettings):
    """
    Configuration class for the test framework, loading settings from environment variables
    or a .env file. Uses Pydantic for validation and type safety.
    """
    model_config = SettingsConfigDict(env_file='.env', extra='ignore')

    # General Settings
    environment: str = Field("dev", description="The target environment (e.g., dev, qa, prod)")
    base_url: str = Field("https://www.saucedemo.com", description="Base URL for the web application under test")
    api_base_url: str = Field("https://api.example.com", description="Base URL for the API services")
    timeout_ms: int = Field(30000, description="Default timeout for Playwright actions in milliseconds")
    retries: int = Field(1, description="Number of retries for failed Playwright actions or API calls")

    # Playwright Browser Settings
    browser: str = Field("chromium", description="Default browser to use (chromium, firefox, webkit)")
    headless: bool = Field(True, description="Run browser in headless mode")
    trace_enabled: bool = Field(False, description="Enable Playwright tracing for debugging")
    video_enabled: bool = Field(False, description="Record video of test execution")
    screenshot_enabled: bool = Field(True, description="Take screenshots on test failure")

    # AI Healing Settings
    enable_ai_healing: bool = Field(False, description="Enable AI-powered locator self-healing")
    ai_service_endpoint: str = Field("http://localhost:8000/heal_locator", description="Endpoint for the AI healing service")

    # Reporting Settings
    allure_results_dir: str = Field("allure-results", description="Directory for Allure test results")

    # API Client Settings
    api_default_headers: dict = Field(
        {"Content-Type": "application/json", "Accept": "application/json"},
        description="Default headers for API requests"
    )

    # Credentials (example, typically loaded securely or from a vault)
    standard_user: str = Field("standard_user", description="Username for standard user")
    locked_out_user: str = Field("locked_out_user", description="Username for locked out user")
    problem_user: str = Field("problem_user", description="Username for problem user")
    performance_glitch_user: str = Field("performance_glitch_user", description="Username for performance glitch user")
    secret_sauce: str = Field("secret_sauce", description="Password for all SauceDemo users")

    def get_base_url(self) -> str:
        """Returns the configured base URL."""
        return self.base_url

    def get_api_base_url(self) -> str:
        """Returns the configured API base URL."""
        return self.api_base_url

    def get_timeout(self) -> int:
        """Returns the default timeout in milliseconds."""
        return self.timeout_ms

    def get_browser(self) -> str:
        """Returns the default browser."""
        return self.browser

    def is_ai_healing_enabled(self) -> bool:
        """Checks if AI healing is enabled."""
        return self.enable_ai_healing

# Instantiate the configuration for easy import
app_config = Config()