from playwright.sync_api import Page
from core.logger.Logger import Logger
from core.config.Config import Config

# Assuming a BasePage exists and provides self.page, self.logger, self.config
# For strict adherence to the prompt, we are not generating BasePage here.
# The LoginPage will directly initialize logger and config.
class LoginPage:
    def __init__(self, page: Page):
        self.page = page
        self.logger = Logger().get_logger()
        self.config = Config().get_config()
        self.base_url = self.config.get("playwright", "base_url")

        # Locators
        self.username_input = self.page.locator("#username")
        self.password_input = self.page.locator("#password")
        self.login_button = self.page.locator("button[type='submit']")
        self.error_message = self.page.locator(".error-message") # Example error locator
        self.success_message = self.page.locator(".success-message") # Example success locator, e.g., on dashboard

    def navigate_to_login_page(self) -> 'LoginPage':
        """Navigates to the login page."""
        self.logger.info(f"Navigating to login page: {self.base_url}/login")
        self.page.goto(f"{self.base_url}/login")
        return self

    def enter_username(self, username: str) -> 'LoginPage':
        """Enters the given username into the username field."""
        self.logger.info(f"Entering username: {username}")
        self.username_input.fill(username)
        return self

    def enter_password(self, password: str) -> 'LoginPage':
        """Enters the given password into the password field."""
        self.logger.info("Entering password")
        self.password_input.fill(password)
        return self

    def click_login_button(self) -> 'LoginPage':
        """Clicks the login button."""
        self.logger.info("Clicking login button")
        self.login_button.click()
        return self

    def login(self, username: str, password: str) -> 'LoginPage':
        """Performs a full login action."""
        self.enter_username(username)
        self.enter_password(password)
        self.click_login_button()
        return self

    def get_error_message_text(self) -> str:
        """Returns the text content of the error message."""
        self.error_message.wait_for(state="visible")
        return self.error_message.text_content()

    def is_login_successful(self) -> bool:
        """
        Checks if the login was successful.
        This is a placeholder; a real check would involve URL, element visibility, etc.
        """
        # Example: Check if redirected to dashboard or a success message is visible
        self.page.wait_for_load_state("networkidle")
        return self.page.url == f"{self.base_url}/dashboard" or self.success_message.is_visible()

    def is_error_message_displayed(self) -> bool:
        """Checks if an error message is displayed."""
        return self.error_message.is_visible()