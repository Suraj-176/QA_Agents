import allure
from pytest_bdd import scenario, given, when, then, parsers
from playwright.sync_api import Page
from src.pages.loginPage import LoginPage
from helpers.validators.LoginValidator import LoginValidator
from core.logger.Logger import Logger
import pytest

logger = Logger().get_logger()

# Scenarios
@scenario('../features/ui/login.feature', 'Successful login with valid credentials')
def test_successful_login():
    pass

@scenario('../features/ui/login.feature', 'Unsuccessful login with invalid credentials')
def test_unsuccessful_login():
    pass

# Fixtures
@pytest.fixture(scope="function")
def login_page(page: Page) -> LoginPage:
    """Provides a LoginPage object."""
    return LoginPage(page)

@pytest.fixture(scope="function")
def login_validator() -> LoginValidator:
    """Provides a LoginValidator object."""
    return LoginValidator()

# Given steps
@given('I am on the login page')
@allure.step
def navigate_to_login(login_page: LoginPage):
    logger.info("Given: Navigating to the login page.")
    login_page.navigate_to_login_page()

# When steps
@when(parsers.parse('I enter username "{username}" and password "{password}"'))
@allure.step
def enter_credentials(login_page: LoginPage, username, password):
    logger.info(f"When: Entering username '{username}' and password.")
    login_page.enter_username(username).enter_password(password)

@when('I click the login button')
@allure.step
def click_login(login_page: LoginPage):
    logger.info("When: Clicking the login button.")
    login_page.click_login_button()

# Then steps
@then('I should be logged in successfully')
@allure.step
def verify_successful_login(login_page: LoginPage, login_validator: LoginValidator):
    logger.info("Then: Verifying successful login.")
    with allure.step("Check if login was successful"):
        assert login_validator.is_ui_login_successful(login_page), "Login was not successful."
    logger.info("Login successful.")

@then(parsers.parse('I should see an error message "{expected_message}"'))
@allure.step
def verify_error_message(login_page: LoginPage, login_validator: LoginValidator, expected_message):
    logger.info(f"Then: Verifying error message '{expected_message}'.")
    with allure.step("Check if error message is displayed and matches"):
        actual_message = login_page.get_error_message_text()
        assert login_validator.is_ui_error_message_displayed(login_page, expected_message), \
            f"Error message not displayed or does not match. Expected: '{expected_message}', Actual: '{actual_message}'"
    logger.info("Error message displayed and matched.")