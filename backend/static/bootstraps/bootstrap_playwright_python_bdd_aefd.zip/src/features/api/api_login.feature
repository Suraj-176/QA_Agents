Feature: API Login
  As an API consumer
  I want to be able to log in via the API
  So that I can access protected resources

  Scenario: Successful API login with valid credentials
    Given I have valid API login credentials
    When I send a POST request to the login endpoint with these credentials
    Then the API response should indicate a successful login

  Scenario: Unsuccessful API login with invalid credentials
    Given I have invalid API login credentials
    When I send a POST request to the login endpoint with these credentials
    Then the API response should indicate invalid credentials

  Scenario: Unsuccessful API login with missing required fields
    Given I have partial API login credentials (missing password)
    When I send a POST request to the login endpoint with these credentials
    Then the API response should indicate missing required fields