"""
This file defines Playwright-specific settings that can be imported by conftest.py
or other modules to configure browser behavior, timeouts, etc.
It serves a similar purpose to playwright.config.ts in JavaScript/TypeScript projects.
"""
from core.config.Config import Config

# Load configuration from environment variables or .env file
app_config = Config()

class PlaywrightSettings:
    """
    Centralized Playwright configuration settings.
    """
    BASE_URL = app_config.base_url
    HEADLESS = app_config.headless
    BROWSER = app_config.browser
    TIMEOUT = app_config.timeout_ms
    RETRIES = app_config.retries
    VIEWPORT = {"width": 1920, "height": 1080}
    TRACE_ENABLED = app_config.trace_enabled
    VIDEO_ENABLED = app_config.video_enabled
    SCREENSHOT_ENABLED = app_config.screenshot_enabled

    # Define projects for different browsers if needed, similar to playwright.config.ts
    # For pytest-bdd, we typically manage browser setup via fixtures in conftest.py
    # but these settings guide that setup.
    PROJECTS = {
        "chromium": {
            "browser_name": "chromium",
            "headless": HEADLESS,
            "viewport": VIEWPORT,
        },
        "firefox": {
            "browser_name": "firefox",
            "headless": HEADLESS,
            "viewport": VIEWPORT,
        },
        "webkit": {
            "browser_name": "webkit",
            "headless": HEADLESS,
            "viewport": VIEWPORT,
        },
    }

    # Context options for Playwright browser context
    CONTEXT_OPTIONS = {
        "ignore_https_errors": True,
        "locale": "en-US",
        "timezone_id": "America/Los_Angeles",
    }

    def __init__(self):
        pass

# Instantiate settings for easy import
playwright_settings = PlaywrightSettings()