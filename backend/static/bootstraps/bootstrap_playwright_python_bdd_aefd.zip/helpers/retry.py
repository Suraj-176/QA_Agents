import time
import functools
from typing import Callable, Tuple, Type, Any

# Assuming core.logger.Logger is available
import sys
from pathlib import Path
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))
from core.logger import Logger

def retry(tries: int = 3, delay: float = 1.0, exceptions: Tuple[Type[Exception], ...] = (Exception,)) -> Callable:
    """
    A decorator to retry a function call multiple times if it fails due to specified exceptions.

    Args:
        tries (int): The maximum number of attempts (including the first one).
        delay (float): The delay in seconds between retries.
        exceptions (Tuple[Type[Exception], ...]): A tuple of exception types to catch and retry on.
                                                  Defaults to (Exception,) to catch all exceptions.

    Returns:
        Callable: A decorator that wraps the function with retry logic.
    """
    logger = Logger("RetryHelper").get_logger()

    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            _tries = tries
            while _tries > 1:
                try:
                    return func(*args, **kwargs)
                except exceptions as e:
                    _tries -= 1
                    logger.warning(f"Attempt failed for '{func.__name__}' ({tries - _tries}/{tries}). "
                                   f"Retrying in {delay}s. Error: {e}")
                    time.sleep(delay)
            # Last attempt, if it fails, let the exception propagate
            return func(*args, **kwargs)
        return wrapper
    return decorator

# Example Usage (for demonstration, not part of the framework itself)
if __name__ == "__main__":
    logger = Logger("RetryExample").get_logger()
    call_count = 0

    @retry(tries=3, delay=0.5, exceptions=(AssertionError, ValueError))
    def flaky_function(should_fail: bool = True):
        global call_count
        call_count += 1
        logger.info(f"Executing flaky_function, attempt {call_count}...")
        if should_fail and call_count < 3:
            raise AssertionError("Simulated failure!")
        logger.info("flaky_function succeeded!")
        return "Success"

    logger.info("--- Testing successful retry ---")
    call_count = 0
    result = flaky_function()
    logger.info(f"Result: {result}")
    assert call_count == 3

    logger.info("\n--- Testing permanent failure ---")
    call_count = 0
    try:
        @retry(tries=2, delay=0.1, exceptions=(ValueError,))
        def always_fails():
            global call_count
            call_count += 1
            logger.info(f"Executing always_fails, attempt {call_count}...")
            raise ValueError("This function always fails!")
        always_fails()
    except ValueError as e:
        logger.error(f"Caught expected error: {e}")
        assert call_count == 2