import sys
import os
from pathlib import Path

# Add the project root to sys.path to allow importing core modules
# Assuming 'helpers' is directly under the project root
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

from core.config import Config
from core.logger import Logger
from playwright_settings import STORAGE_STATE_PATH

def global_teardown():
    """
    Performs global teardown tasks after all tests have run.
    This typically includes:
    - Cleaning up temporary files (e.g., storageState.json).
    - Deleting test data created during setup or tests.
    - Generating final reports or sending notifications.
    """
    config = Config()
    logger = Logger("GlobalTeardown").get_logger()

    logger.info("Starting global teardown...")

    try:
        # Clean up authentication state file
        if os.path.exists(STORAGE_STATE_PATH):
            os.remove(STORAGE_STATE_PATH)
            logger.info(f"Removed authentication state file: {STORAGE_STATE_PATH}")
        else:
            logger.info(f"Authentication state file not found, no cleanup needed: {STORAGE_STATE_PATH}")

        # Add any other cleanup logic here, e.g., deleting test data from DB,
        # closing external connections, etc.

        logger.info("Global teardown completed successfully.")

    except Exception as e:
        logger.error(f"Global teardown failed: {e}", exc_info=True)
        sys.exit(1) # Exit with a non-zero code to indicate failure

if __name__ == "__main__":
    global_teardown()