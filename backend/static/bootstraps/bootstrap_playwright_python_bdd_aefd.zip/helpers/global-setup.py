import sys
import os
from pathlib import Path
import json
import time

# Add the project root to sys.path to allow importing core modules
# Assuming 'helpers' is directly under the project root
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

from playwright.sync_api import sync_playwright
from core.config import Config
from core.logger import Logger
from playwright_settings import BASE_URL, USER_EMAIL, USER_PASSWORD, STORAGE_STATE_PATH, HEADLESS_MODE

def global_setup():
    """
    Performs global setup tasks before all tests run.
    This typically includes:
    - Initializing configuration and logger.
    - Performing a login and saving the authentication state (storageState.json).
    - Creating necessary test data or setting up external services.
    """
    config = Config()
    logger = Logger("GlobalSetup").get_logger()

    logger.info("Starting global setup...")

    try:
        with sync_playwright() as p:
            logger.info(f"Launching browser in {'headless' if HEADLESS_MODE else 'headful'} mode...")
            browser = p.chromium.launch(headless=HEADLESS_MODE)
            context = browser.new_context()
            page = context.new_page()

            logger.info(f"Navigating to base URL: {BASE_URL}")
            page.goto(BASE_URL)

            # Example: Perform a login
            # This assumes a simple login form. Adjust selectors as per your application.
            logger.info(f"Attempting to log in with user: {USER_EMAIL}")

            # Wait for the login form to be visible
            page.wait_for_selector('input[name="email"]', timeout=10000)
            page.fill('input[name="email"]', USER_EMAIL)
            page.fill('input[name="password"]', USER_PASSWORD)
            page.click('button[type="submit"]') # Or whatever your login button selector is

            # Wait for navigation after login or for a specific element on the dashboard
            # Adjust this wait condition based on your application's post-login state
            try:
                page.wait_for_url(f"{BASE_URL}/dashboard", timeout=15000) # Example dashboard URL
                logger.info("Successfully navigated to dashboard after login.")
            except Exception as e:
                logger.warning(f"Did not navigate to expected dashboard URL. Current URL: {page.url}. Error: {e}")
                # If navigation doesn't change URL but content does, check for a specific element
                page.wait_for_selector('text="Welcome to Dashboard"', timeout=10000) # Example element
                logger.info("Successfully found dashboard element after login.")


            # Save authentication state
            storage_state = context.storage_state()
            with open(STORAGE_STATE_PATH, "w") as f:
                json.dump(storage_state, f)
            logger.info(f"Authentication state saved to: {STORAGE_STATE_PATH}")

            browser.close()
            logger.info("Browser closed after setup.")

        logger.info("Global setup completed successfully.")

    except Exception as e:
        logger.error(f"Global setup failed: {e}", exc_info=True)
        sys.exit(1) # Exit with a non-zero code to indicate failure

if __name__ == "__main__":
    global_setup()